param(
  [string]$Source,
  [string]$OutDir
)
$ErrorActionPreference = "Continue"
if (-not $Source -or -not (Test-Path -LiteralPath $Source)) { exit 0 }
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path -LiteralPath $csc)) { $csc = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe" }
if (-not (Test-Path -LiteralPath $csc)) { exit 1 }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$fw = Split-Path -Parent $csc
$exe = Join-Path $OutDir "RemoteDesktopInput.exe"
& $csc /nologo /platform:x64 /target:winexe /r:"$fw\System.ServiceProcess.dll" /r:"$fw\System.Core.dll" /out:$exe $Source
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
sc.exe stop RemoteDesktopInput | Out-Null
Start-Sleep -Milliseconds 700
sc.exe delete RemoteDesktopInput | Out-Null
Start-Sleep -Milliseconds 700
& sc.exe create RemoteDesktopInput binPath= "`"$exe`"" start= auto DisplayName= "Remote Desktop Input"
& sc.exe description RemoteDesktopInput "Approved remote control for the signed-in desktop, elevated apps, and the Windows sign-in screen."
& sc.exe start RemoteDesktopInput | Out-Null
exit 0
