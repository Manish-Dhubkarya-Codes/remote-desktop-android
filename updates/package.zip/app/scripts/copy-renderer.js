const fs = require("fs");
const path = require("path");
const srcDir = path.join(__dirname, "..", "src", "renderer");
const destDir = path.join(__dirname, "..", "dist", "renderer");
fs.mkdirSync(destDir, { recursive: true });
for (const file of ["index.html", "styles.css"]) {
  fs.copyFileSync(path.join(srcDir, file), path.join(destDir, file));
}
