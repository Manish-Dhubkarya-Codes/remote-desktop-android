param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class RdWinInput {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT {
    public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit)] public struct INPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public MOUSEINPUT mi;
  }
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int cb);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr value);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  static bool enabled;
  static bool owner;
  static bool left, middle, right;
  static int targetX, targetY, seenX, seenY;
  static int ownerX, ownerY, ctrlX, ctrlY;
  static int homeX, homeY;
  static bool homeSaved;
  static int publishedOX = -1, publishedOY = -1, publishedCX = -1, publishedCY = -1;
  static bool publishedOwner;
  static int sentTick, idleTick;
  static RdWinInput() {
    try {
      if (!SetProcessDpiAwarenessContext((IntPtr)(-4))) SetProcessDPIAware();
    } catch {
      try { SetProcessDPIAware(); } catch { }
    }
  }
  static List<int> held = new List<int>();
  static List<bool> heldExt = new List<bool>();
  static int Elapsed(int start) { return unchecked(Environment.TickCount - start); }
  public static bool SelfHigh() {
    IntPtr tok;
    if (!OpenProcessToken(GetCurrentProcess(), 0x8, out tok)) return false;
    IntPtr buf = Marshal.AllocHGlobal(8);
    int ret;
    bool elevated = false;
    if (GetTokenInformation(tok, 20, buf, 8, out ret)) elevated = Marshal.ReadInt32(buf) != 0;
    Marshal.FreeHGlobal(buf);
    CloseHandle(tok);
    return elevated;
  }
  static int Axis(int value, int origin, int size) {
    if (size <= 1) return 0;
    int n = (int)Math.Round((value - origin) * 65535.0 / (size - 1));
    if (n < 0) return 0;
    if (n > 65535) return 65535;
    return n;
  }
  static uint ButtonFlag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  static void MarkButton(int button, bool down) {
    if (button == 2) right = down;
    else if (button == 1) middle = down;
    else left = down;
  }
  public static void Enable() {
    enabled = true;
    owner = false;
    publishedOwner = false;
    publishedOX = -1;
    POINT p;
    if (GetCursorPos(out p)) {
      ownerX = ctrlX = targetX = seenX = p.X;
      ownerY = ctrlY = targetY = seenY = p.Y;
    }
    sentTick = Environment.TickCount;
    idleTick = sentTick;
  }
  public static void ReleaseHeld() {
    if (left) Place("U", targetX, targetY, 0, 0);
    if (right) Place("U", targetX, targetY, 2, 0);
    if (middle) Place("U", targetX, targetY, 1, 0);
    for (int i = held.Count - 1; i >= 0; i--) Key(false, held[i], heldExt[i]);
    held.Clear();
    heldExt.Clear();
  }
  public static void Disable() {
    enabled = false;
    owner = false;
    ReleaseHeld();
  }
  static bool ButtonsDown() { return left || middle || right; }
  static void RememberHome() {
    if (homeSaved || ButtonsDown()) return;
    POINT p;
    if (!GetCursorPos(out p)) return;
    homeX = p.X;
    homeY = p.Y;
    homeSaved = true;
    ownerX = p.X;
    ownerY = p.Y;
  }
  static void RestoreHome() {
    if (!homeSaved || ButtonsDown()) return;
    SetCursorPos(homeX, homeY);
    seenX = homeX;
    seenY = homeY;
    ownerX = homeX;
    ownerY = homeY;
    sentTick = Environment.TickCount;
    homeSaved = false;
  }
  public static bool Move(int x, int y) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    if (ButtonsDown() && !owner) return Place("M", x, y, 0, 0, 0, false);
    return true;
  }
  public static bool Click(string dir, int x, int y, int button) {
    if (owner) return true;
    if (dir == "D") RememberHome();
    bool ok = Place(dir, x, y, button, 0, 0, true);
    MarkButton(button, dir == "D");
    if (dir != "D") RestoreHome();
    return ok;
  }
  public static bool Double(int x, int y, int button) {
    if (owner) return true;
    Click("D", x, y, button);
    Click("U", x, y, button);
    System.Threading.Thread.Sleep(40);
    Click("D", x, y, button);
    Click("U", x, y, button);
    return true;
  }
  public static bool Wheel(int x, int y, int data, bool horizontal) {
    if (owner) return true;
    RememberHome();
    uint flag = horizontal ? 0x1000u : 0x0800u;
    bool ok = Place("M", x, y, 0, flag, data, true);
    RestoreHome();
    return ok;
  }
  static bool Place(string dir, int x, int y, int button, uint extra) {
    return Place(dir, x, y, button, extra, 0, true);
  }
  static bool SendAbsolute(uint flags, int ax, int ay, int wheel) {
    if (IntPtr.Size == 8) {
      INPUT inp = new INPUT();
      inp.type = 0;
      inp.mi.dx = ax;
      inp.mi.dy = ay;
      inp.mi.mouseData = unchecked((uint)wheel);
      inp.mi.dwFlags = flags;
      if (SendInput(1, new INPUT[] { inp }, Marshal.SizeOf(typeof(INPUT))) != 0) return true;
    }
    mouse_event(flags, (uint)ax, (uint)ay, unchecked((uint)wheel), UIntPtr.Zero);
    return true;
  }
  static bool Place(string dir, int x, int y, int button, uint extra, int wheel, bool moveCursor) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    sentTick = Environment.TickCount;
    int originX = GetSystemMetrics(76);
    int originY = GetSystemMetrics(77);
    int width = GetSystemMetrics(78);
    int height = GetSystemMetrics(79);
    if (width <= 1) width = GetSystemMetrics(0);
    if (height <= 1) height = GetSystemMetrics(1);
    int ax = Axis(x, originX, width);
    int ay = Axis(y, originY, height);
    uint move = 0x0001u | 0x8000u | 0x4000u;
    if (moveCursor) {
      SendAbsolute(move, ax, ay, 0);
      SetCursorPos(x, y);
    }
    if (dir == "D" || dir == "U") SendAbsolute(move | ButtonFlag(dir, button), ax, ay, 0);
    else if (extra != 0) SendAbsolute(move | extra, ax, ay, wheel);
    return true;
  }
  public static void Key(bool down, int vk, bool extended) {
    if (vk <= 0 || vk > 255) return;
    byte scan = (byte)(MapVirtualKey((uint)vk, 0) & 0xFF);
    uint flags = down ? 0u : 2u;
    if (extended || vk == 0x2C) flags |= 1u;
    keybd_event((byte)vk, scan, flags, UIntPtr.Zero);
    int index = -1;
    for (int i = 0; i < held.Count; i++) if (held[i] == vk) { index = i; break; }
    if (down && index < 0) { held.Add(vk); heldExt.Add(extended); }
    if (!down && index >= 0) { held.RemoveAt(index); heldExt.RemoveAt(index); }
  }
  public static bool TypeChar(int codePoint) {
    if (codePoint < 0 || codePoint > 0xFFFF) return false;
    short packed = VkKeyScan((char)codePoint);
    if (packed == -1) return false;
    int vk = packed & 0xFF;
    int mods = (packed >> 8) & 0xFF;
    if ((mods & 1) != 0) Key(true, 0x10, false);
    if ((mods & 2) != 0) Key(true, 0x11, false);
    if ((mods & 4) != 0) Key(true, 0x12, false);
    Key(true, vk, false);
    Key(false, vk, false);
    if ((mods & 4) != 0) Key(false, 0x12, false);
    if ((mods & 2) != 0) Key(false, 0x11, false);
    if ((mods & 1) != 0) Key(false, 0x10, false);
    return true;
  }
  public static string CursorLine() {
    if (!enabled) return "";
    POINT p;
    if (!GetCursorPos(out p)) return "";
    int now = Environment.TickCount;
    bool recent = Elapsed(sentTick) < 180;
    double fromTarget = Math.Sqrt((p.X - targetX) * (p.X - targetX) + (p.Y - targetY) * (p.Y - targetY));
    double fromPrev = Math.Sqrt((p.X - seenX) * (p.X - seenX) + (p.Y - seenY) * (p.Y - seenY));
    seenX = p.X;
    seenY = p.Y;
    if (!owner) {
      if (!recent && fromPrev > 6) {
        owner = true;
        idleTick = now;
        ownerX = p.X;
        ownerY = p.Y;
      }
    } else if (fromPrev > 3) {
      idleTick = now;
      ownerX = p.X;
      ownerY = p.Y;
    } else if (!recent && Elapsed(idleTick) > 1200) {
      owner = false;
    }
    if (owner == publishedOwner && ownerX == publishedOX && ownerY == publishedOY && ctrlX == publishedCX && ctrlY == publishedCY) return "";
    publishedOwner = owner;
    publishedOX = ownerX;
    publishedOY = ownerY;
    publishedCX = ctrlX;
    publishedCY = ctrlY;
    return "cursor " + (owner ? "1" : "0") + " " + ownerX + " " + ownerY + " " + ctrlX + " " + ctrlY;
  }
}
"@
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$reader = New-Object System.IO.StreamReader($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine($(if ([RdWinInput]::SelfHigh()) { "ready high" } else { "ready low" }))
$skipRestore = $false
try {
  while ($true) {
    $cursor = [RdWinInput]::CursorLine()
    if ($cursor) { $writer.WriteLine($cursor) }
    if (-not $stream.DataAvailable) { Start-Sleep -Milliseconds 12; continue }
    $line = $reader.ReadLine()
    if ($null -eq $line) { break }
    $p = $line.Trim().Split(" ")
    if ($p.Length -lt 2) { continue }
    $id = $p[0]
    $cmd = $p[1]
    if ($cmd -eq "HANDOFF") { $skipRestore = $true; $writer.WriteLine("$id ok"); break }
    $ok = $true
    if ($cmd -eq "ENABLE") { [RdWinInput]::Enable() }
    elseif ($cmd -eq "DISABLE") { [RdWinInput]::Disable() }
    elseif ($cmd -eq "MOVE" -and $p.Length -ge 4) { $ok = [RdWinInput]::Move([int]$p[2], [int]$p[3]) }
    elseif (($cmd -eq "DOWN" -or $cmd -eq "UP") -and $p.Length -ge 5) { $ok = [RdWinInput]::Click($(if ($cmd -eq "DOWN") { "D" } else { "U" }), [int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "DBL" -and $p.Length -ge 5) { $ok = [RdWinInput]::Double([int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "WHEEL" -and $p.Length -ge 6) { $ok = [RdWinInput]::Wheel([int]$p[2], [int]$p[3], [int]$p[4], $p[5] -eq "1") }
    elseif ($cmd -eq "KEY" -and $p.Length -ge 5) { [RdWinInput]::Key($p[2] -eq "d", [int]$p[3], $p[4] -eq "1") }
    elseif ($cmd -eq "TEXT" -and $p.Length -ge 3) { $ok = [RdWinInput]::TypeChar([int]$p[2]) }
    $writer.WriteLine("$id $(if ($ok) { 'ok' } else { 'fail' })")
  }
} finally {
  if (-not $skipRestore) { [RdWinInput]::Disable() }
  $writer.Dispose()
  $reader.Dispose()
  $client.Close()
}
