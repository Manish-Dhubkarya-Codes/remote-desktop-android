param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class RdAdminClick {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("advapi32.dll")] public static extern IntPtr GetSidSubAuthority(IntPtr sid, uint index);
  [DllImport("advapi32.dll")] public static extern IntPtr GetSidSubAuthorityCount(IntPtr sid);
  [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  static POINT parked;
  static bool held;
  public static bool High(int x, int y) {
    IntPtr hwnd = WindowFromPoint(new POINT { X = x, Y = y });
    if (hwnd == IntPtr.Zero) return false;
    uint pid; GetWindowThreadProcessId(hwnd, out pid);
    IntPtr proc = OpenProcess(0x1000, false, pid);
    if (proc == IntPtr.Zero) return true;
    bool high = false;
    IntPtr tok;
    if (OpenProcessToken(proc, 0x8, out tok)) {
      int size; GetTokenInformation(tok, 25, IntPtr.Zero, 0, out size);
      if (size > 0) {
        IntPtr buf = Marshal.AllocHGlobal(size);
        int ret;
        if (GetTokenInformation(tok, 25, buf, size, out ret)) {
          IntPtr sid = Marshal.ReadIntPtr(buf);
          byte count = Marshal.ReadByte(GetSidSubAuthorityCount(sid));
          int rid = Marshal.ReadInt32(GetSidSubAuthority(sid, (uint)(count - 1)));
          high = rid >= 0x3000;
        }
        Marshal.FreeHGlobal(buf);
      }
      CloseHandle(tok);
    }
    CloseHandle(proc);
    return high;
  }
  static uint Flag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  public static void Act(string dir, int x, int y, int button) {
    if (dir == "D" && !held) { GetCursorPos(out parked); held = true; }
    SetCursorPos(x, y);
    if (dir == "M") return;
    mouse_event(Flag(dir, button), 0, 0, 0, UIntPtr.Zero);
    if (dir == "U") { held = false; SetCursorPos(parked.X, parked.Y); }
  }
}
"@
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$reader = New-Object System.IO.StreamReader($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine("ready")
while (($line = $reader.ReadLine()) -ne $null) {
  $p = $line.Trim().Split(" ")
  if ($p.Length -lt 2) { continue }
  $answer = "ok"
  if ($p[1] -eq "P" -and $p.Length -ge 4) {
    if ([RdAdminClick]::High([int]$p[2], [int]$p[3])) { $answer = "H" } else { $answer = "L" }
  } elseif (($p[1] -eq "D" -or $p[1] -eq "U" -or $p[1] -eq "M") -and $p.Length -ge 5) {
    [RdAdminClick]::Act($p[1], [int]$p[2], [int]$p[3], [int]$p[4])
  }
  $writer.WriteLine("$($p[0]) $answer")
}
