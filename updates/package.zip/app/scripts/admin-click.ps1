param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class RdWinInput {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] struct ICONINFO { public bool fIcon; public int xHotspot; public int yHotspot; public IntPtr hbmMask; public IntPtr hbmColor; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT {
    public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit)] public struct INPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public MOUSEINPUT mi;
  }
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int cb);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern IntPtr LoadCursor(IntPtr inst, int id);
  [DllImport("user32.dll")] public static extern IntPtr CopyIcon(IntPtr icon);
  [DllImport("user32.dll")] public static extern bool DrawIconEx(IntPtr hdc, int x, int y, IntPtr icon, int w, int h, uint step, IntPtr brush, uint flags);
  [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr icon);
  [DllImport("user32.dll")] public static extern bool SetSystemCursor(IntPtr cursor, uint id);
  [DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr inst, int xHot, int yHot, int width, int height, byte[] andMask, byte[] xorMask);
  [DllImport("user32.dll")] static extern IntPtr CreateIconIndirect(ref ICONINFO info);
  [DllImport("gdi32.dll")] static extern IntPtr CreateBitmap(int w, int h, uint planes, uint bits, byte[] data);
  [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint action, uint param, IntPtr value, uint winini);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll", EntryPoint="SendInput")] public static extern uint SendInputKey(uint n, KINPUT[] inputs, int cb);
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT {
    public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit)] public struct KINPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public KEYBDINPUT ki;
  }
  [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr CreateWindowEx(int ex, string cls, string title, int style, int x, int y, int w, int h, IntPtr parent, IntPtr menu, IntPtr inst, IntPtr param);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int cmd);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] static extern bool SetWindowDisplayAffinity(IntPtr hwnd, uint affinity);
  [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT dst, ref SIZE size, IntPtr hdcSrc, ref POINT src, uint key, ref BLENDFUNCTION blend, uint flags);
  [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hwnd);
  [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);
  [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hdc);
  [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
  [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
  [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO bmi, uint usage, out IntPtr bits, IntPtr section, uint offset);
  [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx; public int cy; }
  [StructLayout(LayoutKind.Sequential)] struct BLENDFUNCTION { public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat; }
  [StructLayout(LayoutKind.Sequential)] struct BITMAPINFOHEADER {
    public int biSize, biWidth, biHeight; public short biPlanes, biBitCount; public int biCompression, biSizeImage, biXPelsPerMeter, biYPelsPerMeter, biClrUsed, biClrImportant;
  }
  [StructLayout(LayoutKind.Sequential)] struct BITMAPINFO { public BITMAPINFOHEADER bmiHeader; }
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr value);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr hwnd, System.Text.StringBuilder text, int count);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd, System.Text.StringBuilder text, int count);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr process, int flags, System.Text.StringBuilder name, ref int size);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  static bool enabled;
  static bool owner;
  static bool left, middle, right, back, forward;
  static int targetX, targetY, seenX, seenY;
  static int ownerX, ownerY, ctrlX, ctrlY;
  static int homeX, homeY;
  static bool homeSaved;
  static int publishedOX = -1, publishedOY = -1, publishedCX = -1, publishedCY = -1;
  static bool publishedOwner;
  static int sentTick, idleTick;
  static bool ctrlSeen;
  static IntPtr markHwnd;
  static IntPtr ownerHwnd;
  static RdWinInput() {
    try {
      if (!SetProcessDpiAwarenessContext((IntPtr)(-4))) SetProcessDPIAware();
    } catch {
      try { SetProcessDPIAware(); } catch { }
    }
  }
  static List<int> held = new List<int>();
  static List<bool> heldExt = new List<bool>();
  static int Elapsed(int start) { return unchecked(Environment.TickCount - start); }
  public static bool SelfHigh() {
    IntPtr tok;
    if (!OpenProcessToken(GetCurrentProcess(), 0x8, out tok)) return false;
    IntPtr buf = Marshal.AllocHGlobal(8);
    int ret;
    bool elevated = false;
    if (GetTokenInformation(tok, 20, buf, 8, out ret)) elevated = Marshal.ReadInt32(buf) != 0;
    Marshal.FreeHGlobal(buf);
    CloseHandle(tok);
    return elevated;
  }
  static int Axis(int value, int origin, int size) {
    if (size <= 1) return 0;
    int n = (int)Math.Round((value - origin) * 65535.0 / (size - 1));
    if (n < 0) return 0;
    if (n > 65535) return 65535;
    return n;
  }
  static uint ButtonFlag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    if (button == 3 || button == 4) return dir == "D" ? 0x0080u : 0x0100u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  static void MarkButton(int button, bool down) {
    if (button == 2) right = down;
    else if (button == 1) middle = down;
    else if (button == 3) back = down;
    else if (button == 4) forward = down;
    else left = down;
  }
  public static void Enable() {
    enabled = true;
    owner = false;
    ctrlSeen = false;
    publishedOwner = false;
    publishedOX = -1;
    POINT p;
    if (GetCursorPos(out p)) {
      ownerX = ctrlX = targetX = seenX = p.X;
      ownerY = ctrlY = targetY = seenY = p.Y;
    }
    sentTick = Environment.TickCount;
    idleTick = sentTick;
    SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0);
    arrowHidden = false;
    ShowMark(false);
  }
  public static void ReleaseHeld() {
    if (left) Place("U", targetX, targetY, 0, 0);
    if (right) Place("U", targetX, targetY, 2, 0);
    if (middle) Place("U", targetX, targetY, 1, 0);
    for (int i = held.Count - 1; i >= 0; i--) Key(false, held[i], heldExt[i]);
    held.Clear();
    heldExt.Clear();
  }
  public static void Disable() {
    enabled = false;
    owner = false;
    ctrlSeen = false;
    ShowMark(false);
    ShowOwnerMark(false);
    ShowSystemCursor();
    ReleaseHeld();
  }
  static bool ButtonsDown() { return left || middle || right || back || forward; }
  static void RememberHome() {
    if (homeSaved || ButtonsDown()) return;
    POINT p;
    if (!GetCursorPos(out p)) return;
    homeX = p.X;
    homeY = p.Y;
    homeSaved = true;
    ownerX = p.X;
    ownerY = p.Y;
  }
  static bool arrowHidden;
  static IntPtr savedArrow;
  static void HideArrow() {
    if (arrowHidden) return;
    if (savedArrow == IntPtr.Zero) savedArrow = CopyIcon(LoadCursor(IntPtr.Zero, 32512));
    IntPtr blank = BlankCursor();
    if (blank != IntPtr.Zero) SetSystemCursor(blank, 32512);
    arrowHidden = true;
  }
  static void ShowArrow() {
    if (!arrowHidden) return;
    IntPtr copy = savedArrow == IntPtr.Zero ? IntPtr.Zero : CopyIcon(savedArrow);
    if (copy != IntPtr.Zero) SetSystemCursor(copy, 32512);
    else SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0);
    arrowHidden = false;
  }
  static void HideSystemCursor() { HideArrow(); }
  static IntPtr BlankCursor() {
    int width = 32;
    int height = 32;
    BITMAPINFO info = new BITMAPINFO();
    info.bmiHeader.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    IntPtr bits;
    IntPtr screen = GetDC(IntPtr.Zero);
    IntPtr color = CreateDIBSection(screen, ref info, 0, out bits, IntPtr.Zero, 0);
    ReleaseDC(IntPtr.Zero, screen);
    byte[] maskBits = new byte[(width * height) / 8];
    for (int i = 0; i < maskBits.Length; i++) maskBits[i] = 0xFF;
    IntPtr mask = CreateBitmap(width, height, 1, 1, maskBits);
    ICONINFO icon = new ICONINFO();
    icon.fIcon = false;
    icon.xHotspot = 0;
    icon.yHotspot = 0;
    icon.hbmMask = mask;
    icon.hbmColor = color;
    IntPtr cursor = CreateIconIndirect(ref icon);
    if (mask != IntPtr.Zero) DeleteObject(mask);
    if (color != IntPtr.Zero) DeleteObject(color);
    return cursor;
  }
  static void ShowSystemCursor() {
    ShowArrow();
    SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0);
    arrowHidden = false;
    arrowHidden = false;
  }
  static void RestoreHome() {
    if (!homeSaved || ButtonsDown()) return;
    SetCursorPos(homeX, homeY);
    seenX = homeX;
    seenY = homeY;
    ownerX = homeX;
    ownerY = homeY;
    sentTick = Environment.TickCount;
    homeSaved = false;
    ShowArrow();
  }
  static bool snipWas;
  static bool SnippingOpen() {
    try {
      IntPtr hwnd = GetForegroundWindow();
      uint pid;
      GetWindowThreadProcessId(hwnd, out pid);
      if (pid == 0) return false;
      IntPtr proc = OpenProcess(0x1000, false, pid);
      if (proc == IntPtr.Zero) return false;
      System.Text.StringBuilder sb = new System.Text.StringBuilder(300);
      int n = 300;
      QueryFullProcessImageName(proc, 0, sb, ref n);
      CloseHandle(proc);
      string name = sb.ToString().ToLowerInvariant();
      System.Text.StringBuilder title = new System.Text.StringBuilder(200);
      GetWindowText(hwnd, title, 200);
      System.Text.StringBuilder cls = new System.Text.StringBuilder(200);
      GetClassName(hwnd, cls, 200);
      string extra = (title.ToString() + " " + cls.ToString()).ToLowerInvariant();
      return name.Contains("snipping") || name.Contains("screensketch") || name.Contains("screenclip") || name.Contains("pickerhost") || extra.Contains("snip") || extra.Contains("clip");
    } catch { return false; }
  }
  static bool hideMark;
  public static void Mark(int x, int y) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
  }
  public static bool Move(int x, int y) {
    if (owner) return true;
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
    bool snip = SnippingOpen();
    if (snipWas && !snip) RestoreHome();
    snipWas = snip;
    sentTick = Environment.TickCount;
    if (ButtonsDown()) return Place("M", x, y, 0, 0, 0, true);
    return true;
  }
  public static bool Click(string dir, int x, int y, int button) {
    if (owner) return true;
    bool snip = SnippingOpen();
    snipWas = snip;
    if (dir == "D") RememberHome();
    bool ok = Place(dir, x, y, button, 0, 0, true);
    MarkButton(button, dir == "D");
    if (dir != "D") RestoreHome();
    return ok;
  }
  public static bool Double(int x, int y, int button) {
    if (owner) return true;
    Click("D", x, y, button);
    Click("U", x, y, button);
    System.Threading.Thread.Sleep(40);
    Click("D", x, y, button);
    Click("U", x, y, button);
    return true;
  }
  public static bool Wheel(int x, int y, int data, bool horizontal) {
    if (owner) return true;
    RememberHome();
    uint flag = horizontal ? 0x1000u : 0x0800u;
    bool ok = Place("M", x, y, 0, flag, data, true);
    RestoreHome();
    return ok;
  }
  static bool Place(string dir, int x, int y, int button, uint extra) {
    return Place(dir, x, y, button, extra, 0, true);
  }
  static bool SendAbsolute(uint flags, int ax, int ay, int wheel) {
    if (IntPtr.Size == 8) {
      INPUT inp = new INPUT();
      inp.type = 0;
      inp.mi.dx = ax;
      inp.mi.dy = ay;
      inp.mi.mouseData = unchecked((uint)wheel);
      inp.mi.dwFlags = flags;
      if (SendInput(1, new INPUT[] { inp }, Marshal.SizeOf(typeof(INPUT))) != 0) return true;
    }
    mouse_event(flags, (uint)ax, (uint)ay, unchecked((uint)wheel), UIntPtr.Zero);
    return true;
  }
  static bool Place(string dir, int x, int y, int button, uint extra, int wheel, bool moveCursor) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    sentTick = Environment.TickCount;
    int originX = GetSystemMetrics(76);
    int originY = GetSystemMetrics(77);
    int width = GetSystemMetrics(78);
    int height = GetSystemMetrics(79);
    if (width <= 1) width = GetSystemMetrics(0);
    if (height <= 1) height = GetSystemMetrics(1);
    int ax = Axis(x, originX, width);
    int ay = Axis(y, originY, height);
    uint move = 0x0001u | 0x8000u | 0x4000u;
    if (moveCursor) {
      ShowArrow();
      SendAbsolute(move, ax, ay, 0);
      SetCursorPos(x, y);
    }
    if (dir == "D" || dir == "U") SendAbsolute(move | ButtonFlag(dir, button), ax, ay, button == 3 ? 1 : button == 4 ? 2 : 0);
    else if (extra != 0) SendAbsolute(move | extra, ax, ay, wheel);
    return true;
  }
  public static void Key(bool down, int vk, bool extended) {
    if (vk == 0x2C) {
      KINPUT snap = new KINPUT();
      snap.type = 1;
      snap.ki.wVk = 0;
      snap.ki.wScan = 0x37;
      snap.ki.dwFlags = (down ? 0u : 2u) | 1u | 8u;
      if (SendInputKey(1, new KINPUT[] { snap }, Marshal.SizeOf(typeof(KINPUT))) == 0)
        keybd_event(0x2C, 0x37, (down ? 0u : 2u) | 1u, UIntPtr.Zero);
      return;
    }
    if (vk <= 0 || vk > 255) return;
    byte scan = (byte)(MapVirtualKey((uint)vk, 0) & 0xFF);
    uint flags = down ? 0u : 2u;
    if (extended || vk == 0x5B || vk == 0x5C || vk == 0x2C) flags |= 1u;
    KINPUT inp = new KINPUT();
    inp.type = 1;
    inp.ki.wVk = (ushort)vk;
    inp.ki.wScan = scan;
    inp.ki.dwFlags = flags;
    if (SendInputKey(1, new KINPUT[] { inp }, Marshal.SizeOf(typeof(KINPUT))) == 0)
      keybd_event((byte)vk, scan, flags, UIntPtr.Zero);
    int index = -1;
    for (int i = 0; i < held.Count; i++) if (held[i] == vk) { index = i; break; }
    if (down && index < 0) { held.Add(vk); heldExt.Add(extended); }
    if (!down && index >= 0) { held.RemoveAt(index); heldExt.RemoveAt(index); }
  }
  public static bool TypeChar(int codePoint) {
    if (codePoint < 0 || codePoint > 0xFFFF) return false;
    short packed = VkKeyScan((char)codePoint);
    if (packed == -1) return false;
    int vk = packed & 0xFF;
    int mods = (packed >> 8) & 0xFF;
    if ((mods & 1) != 0) Key(true, 0x10, false);
    if ((mods & 2) != 0) Key(true, 0x11, false);
    if ((mods & 4) != 0) Key(true, 0x12, false);
    Key(true, vk, false);
    Key(false, vk, false);
    if ((mods & 4) != 0) Key(false, 0x12, false);
    if ((mods & 2) != 0) Key(false, 0x11, false);
    if ((mods & 1) != 0) Key(false, 0x10, false);
    return true;
  }
  static void Plot(IntPtr bits, int width, int height, int x, int y, int color) {
    if (x < 0 || y < 0 || x >= width || y >= height) return;
    Marshal.WriteInt32(bits, (y * width + x) * 4, color);
  }
  static void FillArrow(IntPtr bits, int width, int height, int color) {
    int[] xs = new int[] { 1, 1, 5, 8, 11, 8, 16 };
    int[] ys = new int[] { 1, 21, 16, 24, 23, 15, 15 };
    int n = 7;
    int minY = 1;
    int maxY = 24;
    for (int y = minY; y <= maxY; y++) {
      int a = -1;
      int b = -1;
      for (int i = 0; i < n; i++) {
        int j = (i + 1) % n;
        int y0 = ys[i];
        int y1 = ys[j];
        if (y0 == y1) continue;
        if ((y >= y0 && y < y1) || (y >= y1 && y < y0)) {
          int x = xs[i] + (y - y0) * (xs[j] - xs[i]) / (y1 - y0);
          if (a < 0) a = x;
          else b = x;
        }
      }
      if (a < 0 || b < 0) continue;
      if (a > b) { int t = a; a = b; b = t; }
      for (int x = a; x <= b; x++) Plot(bits, width, height, x, y, color);
    }
  }
  static void PaintMark(bool blocked) {
    if (markHwnd == IntPtr.Zero) return;
    int width = 32;
    int height = 32;
    BITMAPINFO info = new BITMAPINFO();
    info.bmiHeader.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    IntPtr bits;
    IntPtr screen = GetDC(IntPtr.Zero);
    IntPtr mem = CreateCompatibleDC(screen);
    IntPtr dib = CreateDIBSection(screen, ref info, 0, out bits, IntPtr.Zero, 0);
    IntPtr old = SelectObject(mem, dib);
    int count = width * height;
    int[] fill = new int[count];
    int magenta = unchecked((int)0xFFFF00FF);
    for (int i = 0; i < count; i++) fill[i] = magenta;
    Marshal.Copy(fill, 0, bits, count);
    IntPtr arrow = CopyIcon(LoadCursor(IntPtr.Zero, 32512));
    if (arrow != IntPtr.Zero) { DrawIconEx(mem, 0, 0, arrow, 0, 0, 0, IntPtr.Zero, 3); DestroyIcon(arrow); }
    int[] pixels = new int[count];
    Marshal.Copy(bits, pixels, 0, count);
    for (int i = 0; i < count; i++) {
      int c = pixels[i];
      int b = c & 255;
      int g = (c >> 8) & 255;
      int r = (c >> 16) & 255;
      if (Math.Abs(r - 255) < 28 && g < 40 && Math.Abs(b - 255) < 28) { pixels[i] = 0; continue; }
      int lum = (r + g + b) / 3;
      if (lum > 210) pixels[i] = unchecked((int)0xFFFFFFFF);
      else if (lum > 12) pixels[i] = unchecked((int)0xFF2563EB);
      else pixels[i] = 0;
    }
    Marshal.Copy(pixels, 0, bits, count);
    if (blocked) {
      IntPtr blockedCursor = CopyIcon(LoadCursor(IntPtr.Zero, 32648));
      if (blockedCursor != IntPtr.Zero) { DrawIconEx(mem, 14, 14, blockedCursor, 16, 16, 0, IntPtr.Zero, 3); DestroyIcon(blockedCursor); }
    }
    POINT origin = new POINT();
    POINT dst = new POINT();
    dst.X = ctrlX;
    dst.Y = ctrlY;
    SIZE size = new SIZE();
    size.cx = width;
    size.cy = height;
    BLENDFUNCTION blend = new BLENDFUNCTION();
    blend.BlendOp = 0;
    blend.SourceConstantAlpha = 255;
    blend.AlphaFormat = 1;
    UpdateLayeredWindow(markHwnd, screen, ref dst, ref size, mem, ref origin, 0, ref blend, 2);
    SelectObject(mem, old);
    DeleteObject(dib);
    DeleteDC(mem);
    ReleaseDC(IntPtr.Zero, screen);
  }
  static void EnsureMark() {
    if (markHwnd != IntPtr.Zero) return;
    markHwnd = CreateWindowEx(0x80000 | 0x20 | 0x8 | 0x80 | 0x08000000, "Static", "", unchecked((int)0x80000000), 0, 0, 32, 40, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
    if (markHwnd == IntPtr.Zero) return;
    try { SetWindowDisplayAffinity(markHwnd, 0x11); } catch { }
    PaintMark(false);
  }
  static bool markBlocked;
  public static void ShowMark(bool show) {
    if (markHwnd != IntPtr.Zero) ShowWindow(markHwnd, 0);
  }
  static void ShowOwnerMark(bool show) {
    if (!show) {
      if (ownerHwnd != IntPtr.Zero) ShowWindow(ownerHwnd, 0);
      return;
    }
    if (ownerHwnd == IntPtr.Zero) {
      ownerHwnd = CreateWindowEx(0x80000 | 0x20 | 0x8 | 0x80 | 0x08000000, "Static", "", unchecked((int)0x80000000), 0, 0, 32, 40, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
      if (ownerHwnd == IntPtr.Zero) return;
      try { SetWindowDisplayAffinity(ownerHwnd, 0x11); } catch { }
      int width = 32;
      int height = 40;
      BITMAPINFO info = new BITMAPINFO();
      info.bmiHeader.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
      info.bmiHeader.biWidth = width;
      info.bmiHeader.biHeight = -height;
      info.bmiHeader.biPlanes = 1;
      info.bmiHeader.biBitCount = 32;
      IntPtr bits;
      IntPtr screen = GetDC(IntPtr.Zero);
      IntPtr mem = CreateCompatibleDC(screen);
      IntPtr dib = CreateDIBSection(screen, ref info, 0, out bits, IntPtr.Zero, 0);
      IntPtr old = SelectObject(mem, dib);
      int black = unchecked((int)0xFF111111);
      int white = unchecked((int)0xFFFFFFFF);
      int[] ox = new int[] { -1, 0, 1, -1, 1, -1, 0, 1 };
      int[] oy = new int[] { -1, -1, -1, 0, 0, 1, 1, 1 };
      for (int k = 0; k < 8; k++) {
        int[] xs = new int[] { 1 + ox[k], 1 + ox[k], 5 + ox[k], 8 + ox[k], 11 + ox[k], 8 + ox[k], 16 + ox[k] };
        int[] ys = new int[] { 1 + oy[k], 21 + oy[k], 16 + oy[k], 24 + oy[k], 23 + oy[k], 15 + oy[k], 15 + oy[k] };
        int n = 7;
        for (int y = 0; y < height; y++) {
          int a = -1;
          int b = -1;
          for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            int y0 = ys[i];
            int y1 = ys[j];
            if (y0 == y1) continue;
            if ((y >= y0 && y < y1) || (y >= y1 && y < y0)) {
              int x = xs[i] + (y - y0) * (xs[j] - xs[i]) / (y1 - y0);
              if (a < 0) a = x;
              else b = x;
            }
          }
          if (a < 0 || b < 0) continue;
          if (a > b) { int t = a; a = b; b = t; }
          for (int x = a; x <= b; x++) Plot(bits, width, height, x, y, black);
        }
      }
      FillArrow(bits, width, height, white);
      POINT origin = new POINT();
      POINT dst = new POINT();
      dst.X = ownerX;
      dst.Y = ownerY;
      SIZE size = new SIZE();
      size.cx = width;
      size.cy = height;
      BLENDFUNCTION blend = new BLENDFUNCTION();
      blend.BlendOp = 0;
      blend.SourceConstantAlpha = 255;
      blend.AlphaFormat = 1;
      UpdateLayeredWindow(ownerHwnd, screen, ref dst, ref size, mem, ref origin, 0, ref blend, 2);
      SelectObject(mem, old);
      DeleteObject(dib);
      DeleteDC(mem);
      ReleaseDC(IntPtr.Zero, screen);
    }
    SetWindowPos(ownerHwnd, new IntPtr(-1), ownerX, ownerY, 32, 40, 0x0010 | 0x0040);
    ShowWindow(ownerHwnd, 8);
  }
  static bool CoveringUi() {
    try {
      IntPtr hwnd = GetForegroundWindow();
      uint pid;
      GetWindowThreadProcessId(hwnd, out pid);
      if (pid == 0) return false;
      IntPtr proc = OpenProcess(0x1000, false, pid);
      if (proc == IntPtr.Zero) return false;
      System.Text.StringBuilder sb = new System.Text.StringBuilder(300);
      int n = 300;
      QueryFullProcessImageName(proc, 0, sb, ref n);
      CloseHandle(proc);
      string name = sb.ToString().ToLowerInvariant();
      return name.Contains("searchhost") || name.Contains("startmenu") || name.Contains("shellexperience");
    } catch { return false; }
  }
  public static string CursorLine() {
    if (!enabled) return "";
    POINT p;
    if (!GetCursorPos(out p)) return "";
    int now = Environment.TickCount;
    bool recent = Elapsed(sentTick) < 900;
    double fromPrev = Math.Sqrt((p.X - seenX) * (p.X - seenX) + (p.Y - seenY) * (p.Y - seenY));
    double fromCtrl = Math.Sqrt((p.X - ctrlX) * (p.X - ctrlX) + (p.Y - ctrlY) * (p.Y - ctrlY));
    seenX = p.X;
    seenY = p.Y;
    bool ours = recent || fromCtrl < 56;
    if (!owner) {
      if (!ours && fromPrev > 12) {
        owner = true;
        idleTick = now;
        ownerX = p.X;
        ownerY = p.Y;
        homeX = p.X;
        homeY = p.Y;
        homeSaved = true;
      }
    } else if (!ours && fromPrev > 3) {
      idleTick = now;
      ownerX = p.X;
      ownerY = p.Y;
      homeX = p.X;
      homeY = p.Y;
      homeSaved = true;
    } else if (Elapsed(idleTick) > 900) {
      owner = false;
    }
    ShowMark(ctrlSeen);
    if (owner == publishedOwner && ownerX == publishedOX && ownerY == publishedOY && ctrlX == publishedCX && ctrlY == publishedCY) return "";
    publishedOwner = owner;
    publishedOX = ownerX;
    publishedOY = ownerY;
    publishedCX = ctrlX;
    publishedCY = ctrlY;
    return "cursor " + (owner ? "1" : "0") + " " + ownerX + " " + ownerY + " " + ctrlX + " " + ctrlY;
  }
}
"@
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$reader = New-Object System.IO.StreamReader($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine($(if ([RdWinInput]::SelfHigh()) { "ready high" } else { "ready low" }))
$skipRestore = $false
try {
  while ($true) {
    $cursor = [RdWinInput]::CursorLine()
    if ($cursor) { $writer.WriteLine($cursor) }
    if (-not $stream.DataAvailable) { Start-Sleep -Milliseconds 12; continue }
    $line = $reader.ReadLine()
    if ($null -eq $line) { break }
    $p = $line.Trim().Split(" ")
    if ($p.Length -lt 2) { continue }
    $id = $p[0]
    $cmd = $p[1]
    if ($cmd -eq "HANDOFF") { $skipRestore = $true; $writer.WriteLine("$id ok"); break }
    $ok = $true
    if ($cmd -eq "ENABLE") { [RdWinInput]::Enable() }
    elseif ($cmd -eq "DISABLE") { [RdWinInput]::Disable() }
    elseif ($cmd -eq "MARK" -and $p.Length -ge 4) { [RdWinInput]::Mark([int]$p[2], [int]$p[3]) }
    elseif ($cmd -eq "MOVE" -and $p.Length -ge 4) { $ok = [RdWinInput]::Move([int]$p[2], [int]$p[3]) }
    elseif (($cmd -eq "DOWN" -or $cmd -eq "UP") -and $p.Length -ge 5) { $ok = [RdWinInput]::Click($(if ($cmd -eq "DOWN") { "D" } else { "U" }), [int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "DBL" -and $p.Length -ge 5) { $ok = [RdWinInput]::Double([int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "WHEEL" -and $p.Length -ge 6) { $ok = [RdWinInput]::Wheel([int]$p[2], [int]$p[3], [int]$p[4], $p[5] -eq "1") }
    elseif ($cmd -eq "KEY" -and $p.Length -ge 5) { [RdWinInput]::Key($p[2] -eq "d", [int]$p[3], $p[4] -eq "1") }
    elseif ($cmd -eq "TEXT" -and $p.Length -ge 3) { $ok = [RdWinInput]::TypeChar([int]$p[2]) }
    $writer.WriteLine("$id $(if ($ok) { 'ok' } else { 'fail' })")
  }
} finally {
  if (-not $skipRestore) { [RdWinInput]::Disable() }
  $writer.Dispose()
  $reader.Dispose()
  $client.Close()
}
