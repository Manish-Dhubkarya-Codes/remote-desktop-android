param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class RdWinInput {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT {
    public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit)] public struct INPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public MOUSEINPUT mi;
  }
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int cb);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
  [DllImport("user32.dll")] public static extern bool SetSystemCursor(IntPtr hcur, uint id);
  [DllImport("user32.dll")] public static extern IntPtr CopyImage(IntPtr h, uint type, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, IntPtr c, uint d);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr inst, int hx, int hy, int w, int h, byte[] andMask, byte[] xorMask);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  static uint[] ids = new uint[] { 32512, 32513, 32514, 32515, 32516, 32640, 32641, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650 };
  static IntPtr blank;
  static bool blanked;
  static bool enabled;
  static bool owner;
  static bool left, middle, right;
  static int targetX, targetY, seenX, seenY, publishedX = -1, publishedY = -1;
  static bool publishedOwner;
  static int sentTick, idleTick;
  static List<int> held = new List<int>();
  static List<bool> heldExt = new List<bool>();
  static int Elapsed(int start) { return unchecked(Environment.TickCount - start); }
  static IntPtr MakeBlank(int w, int h) {
    if (w < 16 || h < 16 || w > 256 || h > 256) return IntPtr.Zero;
    int row = ((w + 15) / 16) * 2;
    int len = row * h;
    byte[] andMask = new byte[len];
    byte[] xorMask = new byte[len];
    for (int i = 0; i < len; i++) andMask[i] = 255;
    return CreateCursor(IntPtr.Zero, 0, 0, w, h, andMask, xorMask);
  }
  public static void Prepare() {
    SystemParametersInfo(87, 0, IntPtr.Zero, 0);
    blank = MakeBlank(GetSystemMetrics(13), GetSystemMetrics(14));
    if (blank == IntPtr.Zero) blank = MakeBlank(32, 32);
    if (blank == IntPtr.Zero) blank = MakeBlank(48, 48);
    if (blank == IntPtr.Zero) blank = MakeBlank(64, 64);
    blanked = false;
  }
  public static void Blank() {
    if (blanked || blank == IntPtr.Zero) return;
    blanked = true;
    for (int i = 0; i < ids.Length; i++) {
      IntPtr copy = CopyImage(blank, 2, 0, 0, 0);
      if (copy != IntPtr.Zero) SetSystemCursor(copy, ids[i]);
    }
  }
  public static void Unblank() {
    if (!blanked) return;
    blanked = false;
    SystemParametersInfo(87, 0, IntPtr.Zero, 0);
  }
  public static bool SelfHigh() {
    IntPtr tok;
    if (!OpenProcessToken(GetCurrentProcess(), 0x8, out tok)) return false;
    IntPtr buf = Marshal.AllocHGlobal(8);
    int ret;
    bool elevated = false;
    if (GetTokenInformation(tok, 20, buf, 8, out ret)) elevated = Marshal.ReadInt32(buf) != 0;
    Marshal.FreeHGlobal(buf);
    CloseHandle(tok);
    return elevated;
  }
  static int Axis(int value, int origin, int size) {
    if (size <= 1) return 0;
    int n = (int)Math.Round((value - origin) * 65535.0 / (size - 1));
    if (n < 0) return 0;
    if (n > 65535) return 65535;
    return n;
  }
  static uint ButtonFlag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  static void MarkButton(int button, bool down) {
    if (button == 2) right = down;
    else if (button == 1) middle = down;
    else left = down;
  }
  public static void Enable() {
    enabled = true;
    owner = false;
    publishedOwner = false;
    publishedX = -1;
    POINT p;
    if (GetCursorPos(out p)) { targetX = seenX = p.X; targetY = seenY = p.Y; }
    sentTick = Environment.TickCount;
    idleTick = sentTick;
    Prepare();
    Blank();
  }
  public static void ReleaseHeld() {
    if (left) Place("U", targetX, targetY, 0, 0);
    if (right) Place("U", targetX, targetY, 2, 0);
    if (middle) Place("U", targetX, targetY, 1, 0);
    for (int i = held.Count - 1; i >= 0; i--) Key(false, held[i], heldExt[i]);
    held.Clear();
    heldExt.Clear();
  }
  public static void Disable() {
    enabled = false;
    owner = false;
    ReleaseHeld();
    Unblank();
    SystemParametersInfo(87, 0, IntPtr.Zero, 0);
    blanked = false;
  }
  public static bool Move(int x, int y) {
    if (owner) return true;
    return Place("M", x, y, 0, 0);
  }
  public static bool Click(string dir, int x, int y, int button) {
    if (owner) return true;
    bool ok = Place(dir, x, y, button, 0);
    MarkButton(button, dir == "D");
    return ok;
  }
  public static bool Double(int x, int y, int button) {
    if (owner) return true;
    Click("D", x, y, button);
    Click("U", x, y, button);
    System.Threading.Thread.Sleep(40);
    Click("D", x, y, button);
    Click("U", x, y, button);
    return true;
  }
  public static bool Wheel(int x, int y, int data, bool horizontal) {
    if (owner) return true;
    uint flag = horizontal ? 0x1000u : 0x0800u;
    return Place("M", x, y, 0, flag, data);
  }
  static bool Place(string dir, int x, int y, int button, uint extra) {
    return Place(dir, x, y, button, extra, 0);
  }
  static bool Place(string dir, int x, int y, int button, uint extra, int wheel) {
    targetX = x;
    targetY = y;
    sentTick = Environment.TickCount;
    SetCursorPos(x, y);
    int originX = GetSystemMetrics(76);
    int originY = GetSystemMetrics(77);
    int width = GetSystemMetrics(78);
    int height = GetSystemMetrics(79);
    if (width <= 1) width = GetSystemMetrics(0);
    if (height <= 1) height = GetSystemMetrics(1);
    uint flags = 0x0001u | 0x8000u | 0x4000u | extra;
    if (dir == "D" || dir == "U") flags |= ButtonFlag(dir, button);
    int ax = Axis(x, originX, width);
    int ay = Axis(y, originY, height);
    if (IntPtr.Size == 8) {
      INPUT inp = new INPUT();
      inp.type = 0;
      inp.mi.dx = ax;
      inp.mi.dy = ay;
      inp.mi.mouseData = unchecked((uint)wheel);
      inp.mi.dwFlags = flags;
      if (SendInput(1, new INPUT[] { inp }, Marshal.SizeOf(typeof(INPUT))) != 0) return true;
    }
    mouse_event(flags, (uint)ax, (uint)ay, unchecked((uint)wheel), UIntPtr.Zero);
    return true;
  }
  public static void Key(bool down, int vk, bool extended) {
    if (vk <= 0 || vk > 255) return;
    byte scan = (byte)(MapVirtualKey((uint)vk, 0) & 0xFF);
    uint flags = down ? 0u : 2u;
    if (extended || vk == 0x2C) flags |= 1u;
    keybd_event((byte)vk, scan, flags, UIntPtr.Zero);
    int index = -1;
    for (int i = 0; i < held.Count; i++) if (held[i] == vk) { index = i; break; }
    if (down && index < 0) { held.Add(vk); heldExt.Add(extended); }
    if (!down && index >= 0) { held.RemoveAt(index); heldExt.RemoveAt(index); }
  }
  public static bool TypeChar(int codePoint) {
    if (codePoint < 0 || codePoint > 0xFFFF) return false;
    short packed = VkKeyScan((char)codePoint);
    if (packed == -1) return false;
    int vk = packed & 0xFF;
    int mods = (packed >> 8) & 0xFF;
    if ((mods & 1) != 0) Key(true, 0x10, false);
    if ((mods & 2) != 0) Key(true, 0x11, false);
    if ((mods & 4) != 0) Key(true, 0x12, false);
    Key(true, vk, false);
    Key(false, vk, false);
    if ((mods & 4) != 0) Key(false, 0x12, false);
    if ((mods & 2) != 0) Key(false, 0x11, false);
    if ((mods & 1) != 0) Key(false, 0x10, false);
    return true;
  }
  public static string CursorLine() {
    if (!enabled) return "";
    POINT p;
    if (!GetCursorPos(out p)) return "";
    int now = Environment.TickCount;
    bool recent = Elapsed(sentTick) < 180;
    double fromTarget = Math.Sqrt((p.X - targetX) * (p.X - targetX) + (p.Y - targetY) * (p.Y - targetY));
    double fromPrev = Math.Sqrt((p.X - seenX) * (p.X - seenX) + (p.Y - seenY) * (p.Y - seenY));
    seenX = p.X;
    seenY = p.Y;
    if (!owner) {
      if (!recent && fromTarget > 12 && fromPrev > 6) { owner = true; idleTick = now; Unblank(); }
    } else if (fromPrev > 3) {
      idleTick = now;
    } else if (!recent && Elapsed(idleTick) > 1200) {
      owner = false;
      Blank();
    }
    if (p.X == publishedX && p.Y == publishedY && owner == publishedOwner) return "";
    publishedX = p.X;
    publishedY = p.Y;
    publishedOwner = owner;
    return "cursor " + (owner ? "1" : "0") + " " + p.X + " " + p.Y;
  }
}
"@
[RdWinInput]::Prepare()
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$reader = New-Object System.IO.StreamReader($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine($(if ([RdWinInput]::SelfHigh()) { "ready high" } else { "ready low" }))
$skipRestore = $false
try {
  while ($true) {
    $cursor = [RdWinInput]::CursorLine()
    if ($cursor) { $writer.WriteLine($cursor) }
    if (-not $stream.DataAvailable) { Start-Sleep -Milliseconds 12; continue }
    $line = $reader.ReadLine()
    if ($null -eq $line) { break }
    $p = $line.Trim().Split(" ")
    if ($p.Length -lt 2) { continue }
    $id = $p[0]
    $cmd = $p[1]
    if ($cmd -eq "HANDOFF") { $skipRestore = $true; $writer.WriteLine("$id ok"); break }
    $ok = $true
    if ($cmd -eq "ENABLE") { [RdWinInput]::Enable() }
    elseif ($cmd -eq "DISABLE") { [RdWinInput]::Disable() }
    elseif ($cmd -eq "MOVE" -and $p.Length -ge 4) { $ok = [RdWinInput]::Move([int]$p[2], [int]$p[3]) }
    elseif (($cmd -eq "DOWN" -or $cmd -eq "UP") -and $p.Length -ge 5) { $ok = [RdWinInput]::Click($(if ($cmd -eq "DOWN") { "D" } else { "U" }), [int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "DBL" -and $p.Length -ge 5) { $ok = [RdWinInput]::Double([int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "WHEEL" -and $p.Length -ge 6) { $ok = [RdWinInput]::Wheel([int]$p[2], [int]$p[3], [int]$p[4], $p[5] -eq "1") }
    elseif ($cmd -eq "KEY" -and $p.Length -ge 5) { [RdWinInput]::Key($p[2] -eq "d", [int]$p[3], $p[4] -eq "1") }
    elseif ($cmd -eq "TEXT" -and $p.Length -ge 3) { $ok = [RdWinInput]::TypeChar([int]$p[2]) }
    $writer.WriteLine("$id $(if ($ok) { 'ok' } else { 'fail' })")
  }
} finally {
  if (-not $skipRestore) { [RdWinInput]::Disable() }
  $writer.Dispose()
  $reader.Dispose()
  $client.Close()
}
