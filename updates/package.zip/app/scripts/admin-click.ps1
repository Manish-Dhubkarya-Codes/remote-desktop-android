param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
public class RdWinInput {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] struct ICONINFO { public bool fIcon; public int xHotspot; public int yHotspot; public IntPtr hbmMask; public IntPtr hbmColor; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT {
    public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit, Size = 40)] public struct INPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public MOUSEINPUT mi;
  }
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int cb);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern IntPtr LoadCursor(IntPtr inst, int id);
  [DllImport("user32.dll")] public static extern IntPtr CopyIcon(IntPtr icon);
  [DllImport("user32.dll")] public static extern bool DrawIconEx(IntPtr hdc, int x, int y, IntPtr icon, int w, int h, uint step, IntPtr brush, uint flags);
  [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr icon);
  [DllImport("user32.dll")] public static extern bool SetSystemCursor(IntPtr cursor, uint id);
  [DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr inst, int xHot, int yHot, int width, int height, byte[] andMask, byte[] xorMask);
  [DllImport("user32.dll")] static extern IntPtr CreateIconIndirect(ref ICONINFO info);
  [DllImport("gdi32.dll")] static extern IntPtr CreateBitmap(int w, int h, uint planes, uint bits, byte[] data);
  [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint action, uint param, IntPtr value, uint winini);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll")] static extern bool ScreenToClient(IntPtr hwnd, ref POINT p);
  [DllImport("user32.dll")] static extern IntPtr ChildWindowFromPointEx(IntPtr hwnd, POINT p, uint flags);
  [DllImport("user32.dll")] static extern IntPtr SendMessageTimeout(IntPtr hwnd, uint msg, IntPtr wParam, IntPtr lParam, uint flags, uint timeout, out IntPtr result);
  [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hwnd);
  [DllImport("user32.dll")] static extern bool AllowSetForegroundWindow(int pid);
  [DllImport("user32.dll")] static extern IntPtr SetFocus(IntPtr hwnd);
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint from, uint to, bool attach);
  [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll", EntryPoint="SendInput")] public static extern uint SendInputKey(uint n, KINPUT[] inputs, int cb);
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT {
    public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit, Size = 40)] public struct KINPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public KEYBDINPUT ki;
  }
  [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr CreateWindowEx(int ex, string cls, string title, int style, int x, int y, int w, int h, IntPtr parent, IntPtr menu, IntPtr inst, IntPtr param);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int cmd);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] static extern bool SetWindowDisplayAffinity(IntPtr hwnd, uint affinity);
  [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT dst, ref SIZE size, IntPtr hdcSrc, ref POINT src, uint key, ref BLENDFUNCTION blend, uint flags);
  [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hwnd);
  [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);
  [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hdc);
  [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
  [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
  [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO bmi, uint usage, out IntPtr bits, IntPtr section, uint offset);
  [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx; public int cy; }
  [StructLayout(LayoutKind.Sequential)] struct BLENDFUNCTION { public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat; }
  [StructLayout(LayoutKind.Sequential)] struct BITMAPINFOHEADER {
    public int biSize, biWidth, biHeight; public short biPlanes, biBitCount; public int biCompression, biSizeImage, biXPelsPerMeter, biYPelsPerMeter, biClrUsed, biClrImportant;
  }
  [StructLayout(LayoutKind.Sequential)] struct BITMAPINFO { public BITMAPINFOHEADER bmiHeader; }
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr value);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr hwnd, System.Text.StringBuilder text, int count);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd, System.Text.StringBuilder text, int count);
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr process, int flags, System.Text.StringBuilder name, ref int size);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  [DllImport("advapi32.dll")] static extern IntPtr GetSidSubAuthority(IntPtr sid, uint index);
  [DllImport("advapi32.dll")] static extern IntPtr GetSidSubAuthorityCount(IntPtr sid);
  delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);
  [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int id, HookProc proc, IntPtr mod, uint thread);
  [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr hook, int nCode, IntPtr wParam, IntPtr lParam);
  [DllImport("user32.dll")] static extern bool GetMessage(out MSG msg, IntPtr hwnd, uint min, uint max);
  [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }
  const int MAGIC = 0x52444331;
  static bool enabled;
  static volatile bool owner;
  static bool ownerHold;
  static bool left, middle, right, back, forward;
  static int targetX, targetY, seenX, seenY;
  static int ownerX, ownerY, ctrlX, ctrlY;
  static int homeX, homeY, lastInjectX, lastInjectY;
  static bool homeSaved;
  static int publishedOX = -1, publishedOY = -1, publishedCX = -1, publishedCY = -1;
  static bool publishedOwner;
  static int sentTick, idleTick;
  static bool ctrlSeen;
  static int selfLevel = -1;
  static IntPtr markHwnd;
  static IntPtr pressHwnd;
  static IntPtr mouseHook;
  static HookProc mouseHold;
  static RdWinInput() {
    try {
      if (!SetProcessDpiAwarenessContext((IntPtr)(-4))) SetProcessDPIAware();
    } catch {
      try { SetProcessDPIAware(); } catch { }
    }
  }
  static List<int> held = new List<int>();
  static List<bool> heldExt = new List<bool>();
  static int Elapsed(int start) { return unchecked(Environment.TickCount - start); }
  public static bool SelfHigh() {
    IntPtr tok;
    if (!OpenProcessToken(GetCurrentProcess(), 0x8, out tok)) return false;
    IntPtr buf = Marshal.AllocHGlobal(8);
    int ret;
    bool elevated = false;
    if (GetTokenInformation(tok, 20, buf, 8, out ret)) elevated = Marshal.ReadInt32(buf) != 0;
    Marshal.FreeHGlobal(buf);
    CloseHandle(tok);
    return elevated;
  }
  static int Axis(int value, int origin, int size) {
    if (size <= 1) return 0;
    int n = (int)Math.Round((value - origin) * 65535.0 / (size - 1));
    if (n < 0) return 0;
    if (n > 65535) return 65535;
    return n;
  }
  static uint ButtonFlag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    if (button == 3 || button == 4) return dir == "D" ? 0x0080u : 0x0100u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  static void MarkButton(int button, bool down) {
    if (button == 2) right = down;
    else if (button == 1) middle = down;
    else if (button == 3) back = down;
    else if (button == 4) forward = down;
    else left = down;
  }
  public static void Enable() {
    enabled = true;
    owner = false;
    ownerHold = false;
    homeSaved = false;
    ctrlSeen = false;
    pressHwnd = IntPtr.Zero;
    publishedOwner = false;
    publishedOX = -1;
    SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0);
    POINT p;
    if (GetCursorPos(out p)) {
      ownerX = p.X;
      ownerY = p.Y;
      ctrlX = targetX = seenX = p.X;
      ctrlY = targetY = seenY = p.Y;
    }
    sentTick = Environment.TickCount;
    idleTick = sentTick;
    ShowMark(false);
    StartHook();
  }
  public static void ReleaseHeld() {
    if (left) ReleaseButton(0);
    if (right) ReleaseButton(2);
    if (middle) ReleaseButton(1);
    if (back) ReleaseButton(3);
    if (forward) ReleaseButton(4);
    for (int i = held.Count - 1; i >= 0; i--) SendKey(false, held[i], heldExt[i]);
    held.Clear();
    heldExt.Clear();
  }
  public static void Disable() {
    enabled = false;
    owner = false;
    ownerHold = false;
    ctrlSeen = false;
    ShowMark(false);
    SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0);
    ReleaseHeld();
  }
  static bool ButtonsDown() { return left || middle || right || back || forward; }
  static bool SnippingOpen() {
    try {
      IntPtr hwnd = GetForegroundWindow();
      uint pid;
      GetWindowThreadProcessId(hwnd, out pid);
      if (pid == 0) return false;
      IntPtr proc = OpenProcess(0x1000, false, pid);
      if (proc == IntPtr.Zero) return false;
      System.Text.StringBuilder sb = new System.Text.StringBuilder(300);
      int n = 300;
      QueryFullProcessImageName(proc, 0, sb, ref n);
      CloseHandle(proc);
      string name = sb.ToString().ToLowerInvariant();
      System.Text.StringBuilder title = new System.Text.StringBuilder(200);
      GetWindowText(hwnd, title, 200);
      System.Text.StringBuilder cls = new System.Text.StringBuilder(200);
      GetClassName(hwnd, cls, 200);
      string extra = (title.ToString() + " " + cls.ToString()).ToLowerInvariant();
      return name.Contains("snipping") || name.Contains("screensketch") || name.Contains("screenclip") || name.Contains("pickerhost") || extra.Contains("snip") || extra.Contains("clip");
    } catch { return false; }
  }
  public static void Mark(int x, int y) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
    ShowMark(true);
  }
  public static void SetOwner(bool active) {
    owner = active;
    ownerHold = active;
    idleTick = Environment.TickCount;
    if (active) {
      POINT p;
      if (GetCursorPos(out p)) { ownerX = p.X; ownerY = p.Y; }
      if (ButtonsDown()) ReleaseButtonsInPlace();
    }
  }
  static bool hookStarted;
  static IntPtr keyHook;
  static HookProc keyHold;
  static void StartHook() {
    if (hookStarted) return;
    hookStarted = true;
    mouseHold = OnMouse;
    keyHold = OnKey;
    new Thread(() => {
      mouseHook = SetWindowsHookEx(14, mouseHold, IntPtr.Zero, 0);
      keyHook = SetWindowsHookEx(13, keyHold, IntPtr.Zero, 0);
      MSG msg;
      while (GetMessage(out msg, IntPtr.Zero, 0, 0)) { }
    }) { IsBackground = true }.Start();
  }
  static void OwnerActive() {
    owner = true;
    idleTick = Environment.TickCount;
  }
  static IntPtr OnKey(int nCode, IntPtr wParam, IntPtr lParam) {
    return CallNextHookEx(keyHook, nCode, wParam, lParam);
  }
  static IntPtr OnMouse(int nCode, IntPtr wParam, IntPtr lParam) {
    int msg = (int)wParam;
    if (nCode >= 0 && enabled && msg >= 512 && msg <= 526) {
      int flags = Marshal.ReadInt32(lParam, 12);
      int extra = IntPtr.Size == 8 ? Marshal.ReadInt32(lParam, 24) : Marshal.ReadInt32(lParam, 20);
      int x = Marshal.ReadInt32(lParam, 0);
      int y = Marshal.ReadInt32(lParam, 4);
      bool ours = (flags & 1) != 0 || extra == MAGIC || (sentTick != 0 && Elapsed(sentTick) < 300);
      if (!ours) {
        ownerX = x;
        ownerY = y;
        OwnerActive();
      }
    }
    return CallNextHookEx(mouseHook, nCode, wParam, lParam);
  }
  static void ReleaseButtonsInPlace() {
    if (left) mouse_event(0x0004u, 0, 0, 0, (UIntPtr)MAGIC);
    if (right) mouse_event(0x0010u, 0, 0, 0, (UIntPtr)MAGIC);
    if (middle) mouse_event(0x0040u, 0, 0, 0, (UIntPtr)MAGIC);
    if (back) mouse_event(0x0100u, 0, 0, 1, (UIntPtr)MAGIC);
    if (forward) mouse_event(0x0100u, 0, 0, 2, (UIntPtr)MAGIC);
    left = middle = right = back = forward = false;
    pressHwnd = IntPtr.Zero;
  }
  static int LevelOf(IntPtr process) {
    IntPtr tok;
    if (!OpenProcessToken(process, 0x8, out tok)) return 0;
    int len = 0;
    GetTokenInformation(tok, 25, IntPtr.Zero, 0, out len);
    if (len < 16) { CloseHandle(tok); return 0; }
    IntPtr buf = Marshal.AllocHGlobal(len);
    int level = 0;
    if (GetTokenInformation(tok, 25, buf, len, out len)) {
      IntPtr sid = Marshal.ReadIntPtr(buf);
      int count = Marshal.ReadByte(GetSidSubAuthorityCount(sid));
      if (count > 0) level = Marshal.ReadInt32(GetSidSubAuthority(sid, (uint)(count - 1)));
    }
    Marshal.FreeHGlobal(buf);
    CloseHandle(tok);
    return level;
  }
  static int MyLevel() {
    if (selfLevel >= 0) return selfLevel;
    selfLevel = LevelOf(GetCurrentProcess());
    return selfLevel;
  }
  static bool CanInjectHere() { return CanInjectWindow(GetForegroundWindow()); }
  static bool CanInjectPoint(int x, int y) {
    if (SelfHigh()) return true;
    POINT p = new POINT();
    p.X = x;
    p.Y = y;
    IntPtr at = WindowFromPoint(p);
    if (at != IntPtr.Zero && !OurWindow(at) && !CanInjectWindow(at)) return false;
    return CanInjectHere();
  }
  static bool CanInjectWindow(IntPtr hwnd) {
    try {
      if (hwnd == IntPtr.Zero) hwnd = GetForegroundWindow();
      uint pid;
      GetWindowThreadProcessId(hwnd, out pid);
      if (pid == 0) return true;
      IntPtr proc = OpenProcess(0x1000, false, pid);
      if (proc == IntPtr.Zero) return SelfHigh();
      System.Text.StringBuilder sb = new System.Text.StringBuilder(300);
      int n = 300;
      QueryFullProcessImageName(proc, 0, sb, ref n);
      int level = LevelOf(proc);
      CloseHandle(proc);
      string name = sb.ToString().ToLowerInvariant();
      if (name.EndsWith("consent.exe") || name.EndsWith("logonui.exe")) return false;
      if (SelfHigh()) return true;
      if (level >= 0x3000) return false;
      return true;
    } catch { return true; }
  }
  static void SyncOwnerVisual() {
    ShowMark(false);
  }
  static IntPtr MakeLParam(int x, int y) {
    return (IntPtr)(int)((((ushort)y) << 16) | (ushort)x);
  }
  static uint MkFlags() {
    uint mk = 0;
    if (left) mk |= 1;
    if (right) mk |= 2;
    if (middle) mk |= 0x10;
    if (back) mk |= 0x20;
    if (forward) mk |= 0x40;
    return mk;
  }
  static uint ButtonWParam(int button) {
    uint mk = MkFlags();
    if (button == 3) return (1u << 16) | mk;
    if (button == 4) return (2u << 16) | mk;
    return mk;
  }
  static uint DownMsg(int button) {
    if (button == 2) return 0x0204;
    if (button == 1) return 0x0207;
    if (button == 3 || button == 4) return 0x020B;
    return 0x0201;
  }
  static uint UpMsg(int button) {
    if (button == 2) return 0x0205;
    if (button == 1) return 0x0208;
    if (button == 3 || button == 4) return 0x020C;
    return 0x0202;
  }
  static uint DblMsg(int button) {
    if (button == 2) return 0x0206;
    if (button == 1) return 0x0209;
    if (button == 3 || button == 4) return 0x020D;
    return 0x0203;
  }
  static IntPtr HitWindow(int x, int y) {
    POINT screen = new POINT();
    screen.X = x;
    screen.Y = y;
    IntPtr hwnd = WindowFromPoint(screen);
    if (hwnd == IntPtr.Zero || hwnd == markHwnd) return IntPtr.Zero;
    IntPtr child = hwnd;
    for (int i = 0; i < 6; i++) {
      POINT client = screen;
      if (!ScreenToClient(child, ref client)) break;
      IntPtr next = ChildWindowFromPointEx(child, client, 3);
      if (next == IntPtr.Zero || next == child || next == markHwnd) break;
      child = next;
    }
    return child;
  }
  static IntPtr TargetHwnd(int x, int y) {
    if (pressHwnd != IntPtr.Zero && IsWindow(pressHwnd)) return pressHwnd;
    return HitWindow(x, y);
  }
  static void SendMouse(IntPtr hwnd, uint msg, uint wParam, int x, int y, bool screen) {
    if (hwnd == IntPtr.Zero || !IsWindow(hwnd)) return;
    int lx = x;
    int ly = y;
    if (!screen) {
      POINT p = new POINT();
      p.X = x;
      p.Y = y;
      if (!ScreenToClient(hwnd, ref p)) return;
      lx = p.X;
      ly = p.Y;
    }
    IntPtr result;
    SendMessageTimeout(hwnd, msg, (IntPtr)unchecked((int)wParam), MakeLParam(lx, ly), 2, 80, out result);
  }
  static void FocusWindow(IntPtr hwnd) {
    if (hwnd == IntPtr.Zero) return;
    try {
      IntPtr root = GetAncestor(hwnd, 2);
      if (root == IntPtr.Zero) root = hwnd;
      AllowSetForegroundWindow(-1);
      uint pid;
      uint target = GetWindowThreadProcessId(root, out pid);
      uint me = GetCurrentThreadId();
      bool attached = target != 0 && target != me && AttachThreadInput(me, target, true);
      SetForegroundWindow(root);
      SetFocus(hwnd);
      if (attached) AttachThreadInput(me, target, false);
    } catch { }
  }
  static void ReleaseButton(int button) {
    MarkButton(button, false);
    if (!ButtonsDown()) pressHwnd = IntPtr.Zero;
  }
  static void RememberHome() {
    if (homeSaved) return;
    POINT p;
    if (!GetCursorPos(out p)) return;
    homeX = p.X;
    homeY = p.Y;
    homeSaved = true;
  }
  static INPUT Packet(int x, int y, uint flags, int wheel) {
    int originX = GetSystemMetrics(76);
    int originY = GetSystemMetrics(77);
    int width = GetSystemMetrics(78);
    int height = GetSystemMetrics(79);
    if (width <= 1) width = GetSystemMetrics(0);
    if (height <= 1) height = GetSystemMetrics(1);
    INPUT placed = new INPUT();
    placed.type = 0;
    placed.mi.dx = Axis(x, originX, width);
    placed.mi.dy = Axis(y, originY, height);
    placed.mi.mouseData = unchecked((uint)wheel);
    placed.mi.dwFlags = flags;
    placed.mi.dwExtraInfo = (IntPtr)MAGIC;
    return placed;
  }
  static bool Play(INPUT[] inputs) {
    if (inputs == null || inputs.Length == 0) return true;
    sentTick = Environment.TickCount;
    if (IntPtr.Size == 8 && SendInput((uint)inputs.Length, inputs, Marshal.SizeOf(typeof(INPUT))) == (uint)inputs.Length) return true;
    for (int i = 0; i < inputs.Length; i++) mouse_event(inputs[i].mi.dwFlags, unchecked((uint)inputs[i].mi.dx), unchecked((uint)inputs[i].mi.dy), inputs[i].mi.mouseData, (UIntPtr)MAGIC);
    return true;
  }
  static bool SendAbsolute(uint flags, int x, int y, int wheel) {
    lastInjectX = x;
    lastInjectY = y;
    sentTick = Environment.TickCount;
    int originX = GetSystemMetrics(76);
    int originY = GetSystemMetrics(77);
    int width = GetSystemMetrics(78);
    int height = GetSystemMetrics(79);
    if (width <= 1) width = GetSystemMetrics(0);
    if (height <= 1) height = GetSystemMetrics(1);
    int ax = Axis(x, originX, width);
    int ay = Axis(y, originY, height);
    uint move = 0x0001u | 0x8000u | 0x4000u;
    INPUT placed = new INPUT();
    placed.type = 0;
    placed.mi.dx = ax;
    placed.mi.dy = ay;
    placed.mi.dwFlags = move;
    placed.mi.dwExtraInfo = (IntPtr)MAGIC;
    uint actionFlags = flags & ~move;
    if (actionFlags == 0) {
      if (IntPtr.Size == 8 && SendInput(1, new INPUT[] { placed }, Marshal.SizeOf(typeof(INPUT))) != 0) return true;
      mouse_event(move, (uint)ax, (uint)ay, 0, (UIntPtr)MAGIC);
      return true;
    }
    INPUT action = placed;
    action.mi.mouseData = unchecked((uint)wheel);
    action.mi.dwFlags = move | actionFlags;
    if (IntPtr.Size == 8 && SendInput(2, new INPUT[] { placed, action }, Marshal.SizeOf(typeof(INPUT))) == 2) return true;
    mouse_event(move, (uint)ax, (uint)ay, 0, (UIntPtr)MAGIC);
    mouse_event(move | actionFlags, (uint)ax, (uint)ay, unchecked((uint)wheel), (UIntPtr)MAGIC);
    return true;
  }
  [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc proc, IntPtr data);
  [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
  [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr hwnd, int index);
  [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hwnd, int index, int value);
  delegate bool EnumProc(IntPtr hwnd, IntPtr data);
  static EnumProc enumHold;
  static List<IntPtr> openHwnds = new List<IntPtr>();
  static List<int> openStyles = new List<int>();
  static bool OurWindow(IntPtr hwnd) {
    System.Text.StringBuilder title = new System.Text.StringBuilder(220);
    GetWindowText(hwnd, title, 220);
    if (title.ToString().IndexOf("Remote Desktop", StringComparison.OrdinalIgnoreCase) >= 0) return true;
    uint pid;
    GetWindowThreadProcessId(hwnd, out pid);
    if (pid == 0) return false;
    IntPtr proc = OpenProcess(0x1000, false, pid);
    if (proc == IntPtr.Zero) return false;
    System.Text.StringBuilder exe = new System.Text.StringBuilder(300);
    int n = 300;
    QueryFullProcessImageName(proc, 0, exe, ref n);
    CloseHandle(proc);
    string path = exe.ToString().ToLowerInvariant();
    return path.Contains("remotedesktop") || path.Contains("remote-desktop");
  }
  static void Punch(bool on) {
    if (!on) {
      for (int i = 0; i < openHwnds.Count; i++) {
        try { SetWindowLong(openHwnds[i], -20, openStyles[i]); } catch { }
      }
      openHwnds.Clear();
      openStyles.Clear();
      return;
    }
    if (openHwnds.Count > 0) return;
    enumHold = (hwnd, data) => {
      if (IsWindowVisible(hwnd) && OurWindow(hwnd)) {
        int style = GetWindowLong(hwnd, -20);
        if ((style & 0x20) == 0) {
          openHwnds.Add(hwnd);
          openStyles.Add(style);
          SetWindowLong(hwnd, -20, style | 0x00000020 | 0x00080000);
        }
      }
      return true;
    };
    EnumWindows(enumHold, IntPtr.Zero);
  }
  static void Place(int x, int y) {
    sentTick = Environment.TickCount;
    lastInjectX = x;
    lastInjectY = y;
    SetCursorPos(x, y);
  }
  static void Press(bool down, int button, int data) {
    mouse_event(ButtonFlag(down ? "D" : "U", button), 0, 0, unchecked((uint)data), (UIntPtr)MAGIC);
  }
  public static bool Move(int x, int y) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
    return true;
  }
  static bool Strike(bool down, int x, int y, int button) {
    return Strike(down, x, y, button, true);
  }
  static bool Strike(bool down, int x, int y, int button, bool restore) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
    if (down && !ButtonsDown()) RememberHome();
    int data = button == 3 ? 1 : button == 4 ? 2 : 0;
    MarkButton(button, down);
    Punch(true);
    Place(x, y);
    Press(down, button, data);
    if (homeSaved) {
      int hx = homeX;
      int hy = homeY;
      if (restore && !down && !ButtonsDown()) homeSaved = false;
      Place(hx, hy);
    }
    if (!ButtonsDown()) Punch(false);
    return true;
  }
  public static bool Click(string dir, int x, int y, int button) {
    if (!CanInjectPoint(x, y)) return false;
    return Strike(dir == "D", x, y, button);
  }
  public static bool Double(int x, int y, int button) {
    if (!CanInjectPoint(x, y)) return false;
    bool ok = Strike(true, x, y, button, false);
    ok = Strike(false, x, y, button, false) && ok;
    Thread.Sleep(40);
    ok = Strike(true, x, y, button, false) && ok;
    ok = Strike(false, x, y, button, true) && ok;
    return ok;
  }
  public static bool Wheel(int x, int y, int data, bool horizontal) {
    if (!CanInjectPoint(x, y)) return false;
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
    POINT home;
    bool haveHome = !ButtonsDown() && GetCursorPos(out home);
    Punch(true);
    Place(x, y);
    mouse_event(horizontal ? 0x1000u : 0x0800u, 0, 0, unchecked((uint)data), (UIntPtr)MAGIC);
    if (haveHome) Place(home.X, home.Y);
    if (!ButtonsDown()) Punch(false);
    return true;
  }
  public static bool Key(bool down, int vk, bool extended) {
    if (!CanInjectHere()) return false;
    return SendKey(down, vk, extended);
  }
  static bool SendKey(bool down, int vk, bool extended) {
    if (vk == 0x2C) {
      KINPUT snap = new KINPUT();
      snap.type = 1;
      snap.ki.wVk = 0;
      snap.ki.wScan = 0x37;
      snap.ki.dwFlags = (down ? 0u : 2u) | 1u | 8u;
      snap.ki.dwExtraInfo = (IntPtr)MAGIC;
      if (SendInputKey(1, new KINPUT[] { snap }, Marshal.SizeOf(typeof(KINPUT))) == 0)
        keybd_event(0x2C, 0x37, (down ? 0u : 2u) | 1u, (UIntPtr)MAGIC);
      return true;
    }
    if (vk <= 0 || vk > 255) return false;
    byte scan = (byte)(MapVirtualKey((uint)vk, 0) & 0xFF);
    uint flags = down ? 0u : 2u;
    if (extended || vk == 0x5B || vk == 0x5C || vk == 0x2C) flags |= 1u;
    KINPUT inp = new KINPUT();
    inp.type = 1;
    inp.ki.wVk = (ushort)vk;
    inp.ki.wScan = scan;
    inp.ki.dwFlags = flags;
    inp.ki.dwExtraInfo = (IntPtr)MAGIC;
    if (SendInputKey(1, new KINPUT[] { inp }, Marshal.SizeOf(typeof(KINPUT))) == 0)
      keybd_event((byte)vk, scan, flags, (UIntPtr)MAGIC);
    int index = -1;
    for (int i = 0; i < held.Count; i++) if (held[i] == vk) { index = i; break; }
    if (down && index < 0) { held.Add(vk); heldExt.Add(extended); }
    if (!down && index >= 0) { held.RemoveAt(index); heldExt.RemoveAt(index); }
    return true;
  }
  public static bool TypeChar(int codePoint) {
    if (codePoint < 0 || codePoint > 0xFFFF) return false;
    if (!CanInjectHere()) return false;
    short packed = VkKeyScan((char)codePoint);
    if (packed == -1) return false;
    int vk = packed & 0xFF;
    int mods = (packed >> 8) & 0xFF;
    if ((mods & 1) != 0) Key(true, 0x10, false);
    if ((mods & 2) != 0) Key(true, 0x11, false);
    if ((mods & 4) != 0) Key(true, 0x12, false);
    Key(true, vk, false);
    Key(false, vk, false);
    if ((mods & 4) != 0) Key(false, 0x12, false);
    if ((mods & 2) != 0) Key(false, 0x11, false);
    if ((mods & 1) != 0) Key(false, 0x10, false);
    return true;
  }
  static void Plot(IntPtr bits, int width, int height, int x, int y, int color) {
    if (x < 0 || y < 0 || x >= width || y >= height) return;
    Marshal.WriteInt32(bits, (y * width + x) * 4, color);
  }
  static void FillArrow(IntPtr bits, int width, int height, int color) {
    int[] xs = new int[] { 1, 1, 5, 8, 11, 8, 16 };
    int[] ys = new int[] { 1, 21, 16, 24, 23, 15, 15 };
    int n = 7;
    int minY = 1;
    int maxY = 24;
    for (int y = minY; y <= maxY; y++) {
      int a = -1;
      int b = -1;
      for (int i = 0; i < n; i++) {
        int j = (i + 1) % n;
        int y0 = ys[i];
        int y1 = ys[j];
        if (y0 == y1) continue;
        if ((y >= y0 && y < y1) || (y >= y1 && y < y0)) {
          int x = xs[i] + (y - y0) * (xs[j] - xs[i]) / (y1 - y0);
          if (a < 0) a = x;
          else b = x;
        }
      }
      if (a < 0 || b < 0) continue;
      if (a > b) { int t = a; a = b; b = t; }
      for (int x = a; x <= b; x++) Plot(bits, width, height, x, y, color);
    }
  }
  static void PaintMark(bool blocked) {
    if (markHwnd == IntPtr.Zero) return;
    int width = 32;
    int height = 32;
    BITMAPINFO info = new BITMAPINFO();
    info.bmiHeader.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    IntPtr bits;
    IntPtr screen = GetDC(IntPtr.Zero);
    IntPtr mem = CreateCompatibleDC(screen);
    IntPtr dib = CreateDIBSection(screen, ref info, 0, out bits, IntPtr.Zero, 0);
    IntPtr old = SelectObject(mem, dib);
    int count = width * height;
    int[] fill = new int[count];
    int magenta = unchecked((int)0xFFFF00FF);
    for (int i = 0; i < count; i++) fill[i] = magenta;
    Marshal.Copy(fill, 0, bits, count);
    IntPtr arrow = CopyIcon(LoadCursor(IntPtr.Zero, 32512));
    if (arrow != IntPtr.Zero) { DrawIconEx(mem, 0, 0, arrow, 0, 0, 0, IntPtr.Zero, 3); DestroyIcon(arrow); }
    int[] pixels = new int[count];
    Marshal.Copy(bits, pixels, 0, count);
    for (int i = 0; i < count; i++) {
      int c = pixels[i];
      int b = c & 255;
      int g = (c >> 8) & 255;
      int r = (c >> 16) & 255;
      if (Math.Abs(r - 255) < 28 && g < 40 && Math.Abs(b - 255) < 28) { pixels[i] = 0; continue; }
      int lum = (r + g + b) / 3;
      if (lum > 210) pixels[i] = unchecked((int)0xFFFFFFFF);
      else if (lum > 12) pixels[i] = unchecked((int)0xFF2563EB);
      else pixels[i] = 0;
    }
    Marshal.Copy(pixels, 0, bits, count);
    POINT origin = new POINT();
    POINT dst = new POINT();
    dst.X = ctrlX - 1;
    dst.Y = ctrlY - 1;
    SIZE size = new SIZE();
    size.cx = width;
    size.cy = height;
    BLENDFUNCTION blend = new BLENDFUNCTION();
    blend.BlendOp = 0;
    blend.SourceConstantAlpha = 255;
    blend.AlphaFormat = 1;
    UpdateLayeredWindow(markHwnd, screen, ref dst, ref size, mem, ref origin, 0, ref blend, 2);
    SelectObject(mem, old);
    DeleteObject(dib);
    DeleteDC(mem);
    ReleaseDC(IntPtr.Zero, screen);
  }
  static void EnsureMark() {
    if (markHwnd != IntPtr.Zero) return;
    markHwnd = CreateWindowEx(0x80000 | 0x20 | 0x8 | 0x80 | 0x08000000, "Static", "", unchecked((int)0x80000000), 0, 0, 32, 40, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
    if (markHwnd == IntPtr.Zero) return;
    try { SetWindowDisplayAffinity(markHwnd, 0x11); } catch { }
    PaintMark(false);
  }
  static bool markBlocked;
  static int paintedCtrlX = int.MinValue, paintedCtrlY = int.MinValue;
  public static void ShowMark(bool show) {
    if (markHwnd != IntPtr.Zero) ShowWindow(markHwnd, 0);
  }
  static bool CoveringUi() {
    try {
      IntPtr hwnd = GetForegroundWindow();
      uint pid;
      GetWindowThreadProcessId(hwnd, out pid);
      if (pid == 0) return false;
      IntPtr proc = OpenProcess(0x1000, false, pid);
      if (proc == IntPtr.Zero) return false;
      System.Text.StringBuilder sb = new System.Text.StringBuilder(300);
      int n = 300;
      QueryFullProcessImageName(proc, 0, sb, ref n);
      CloseHandle(proc);
      string name = sb.ToString().ToLowerInvariant();
      return name.Contains("searchhost") || name.Contains("startmenu") || name.Contains("shellexperience");
    } catch { return false; }
  }
  public static string CursorLine() {
    if (!enabled) return "";
    if (owner && !ownerHold && Elapsed(idleTick) > 1200) owner = false;
    ShowMark(ctrlSeen && enabled);
    if (owner == publishedOwner && ownerX == publishedOX && ownerY == publishedOY && ctrlX == publishedCX && ctrlY == publishedCY) return "";
    publishedOwner = owner;
    publishedOX = ownerX;
    publishedOY = ownerY;
    publishedCX = ctrlX;
    publishedCY = ctrlY;
    return "cursor " + (owner ? "1" : "0") + " " + ownerX + " " + ownerY + " " + ctrlX + " " + ctrlY;
  }
}
"@
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine($(if ([RdWinInput]::SelfHigh()) { "ready high" } else { "ready low" }))
$skipRestore = $false
$pending = New-Object System.Text.StringBuilder
$utf8 = New-Object System.Text.UTF8Encoding $false
function Handle-Line([string]$line) {
  $p = $line.Trim().Split(" ")
  if ($p.Length -lt 2) { return $true }
  $id = $p[0]
  $cmd = $p[1]
  if ($cmd -eq "HANDOFF") { $script:skipRestore = $true; $writer.WriteLine("$id ok"); return $false }
  $ok = $true
  if ($cmd -eq "ENABLE") { [RdWinInput]::Enable() }
  elseif ($cmd -eq "DISABLE") { [RdWinInput]::Disable() }
  elseif ($cmd -eq "MARK" -and $p.Length -ge 4) { [RdWinInput]::Mark([int]$p[2], [int]$p[3]) }
  elseif ($cmd -eq "OWNER" -and $p.Length -ge 3) { [RdWinInput]::SetOwner($p[2] -eq "1") }
  elseif ($cmd -eq "MOVE" -and $p.Length -ge 4) { $ok = [RdWinInput]::Move([int]$p[2], [int]$p[3]) }
  elseif (($cmd -eq "DOWN" -or $cmd -eq "UP") -and $p.Length -ge 5) { $ok = [RdWinInput]::Click($(if ($cmd -eq "DOWN") { "D" } else { "U" }), [int]$p[2], [int]$p[3], [int]$p[4]) }
  elseif ($cmd -eq "DBL" -and $p.Length -ge 5) { $ok = [RdWinInput]::Double([int]$p[2], [int]$p[3], [int]$p[4]) }
  elseif ($cmd -eq "WHEEL" -and $p.Length -ge 6) { $ok = [RdWinInput]::Wheel([int]$p[2], [int]$p[3], [int]$p[4], $p[5] -eq "1") }
  elseif ($cmd -eq "KEY" -and $p.Length -ge 5) { $ok = [RdWinInput]::Key($p[2] -eq "d", [int]$p[3], $p[4] -eq "1") }
  elseif ($cmd -eq "TEXT" -and $p.Length -ge 3) { $ok = [RdWinInput]::TypeChar([int]$p[2]) }
  $writer.WriteLine("$id $(if ($ok) { 'ok' } else { 'fail' })")
  return $true
}
try {
  while ($client.Connected) {
    $cursor = [RdWinInput]::CursorLine()
    if ($cursor) { $writer.WriteLine($cursor) }
    # Drain the socket itself. A StreamReader keeps the next line in its own
    # buffer, so a key-up that arrived with the key-down never ran until a
    # later event and the key stayed down.
    $ready = $false
    try { $ready = $client.Client.Poll(20000, [System.Net.Sockets.SelectMode]::SelectRead) } catch { break }
    if (-not $ready) { continue }
    if ($client.Available -lt 1) { break }
    $buf = New-Object byte[] $client.Available
    $n = 0
    try { $n = $stream.Read($buf, 0, $buf.Length) } catch { break }
    if ($n -le 0) { break }
    [void]$pending.Append($utf8.GetString($buf, 0, $n))
    $stop = $false
    while ($pending.Length -gt 0) {
      $text = $pending.ToString()
      $nl = $text.IndexOf([char]10)
      if ($nl -lt 0) { break }
      $line = $text.Substring(0, $nl).Trim()
      [void]$pending.Remove(0, $nl + 1)
      if ($line.Length -lt 1) { continue }
      if (-not (Handle-Line $line)) { $stop = $true; break }
    }
    if ($stop) { break }
  }
} finally {
  if (-not $skipRestore) { [RdWinInput]::Disable() }
  $writer.Dispose()
  $client.Close()
}
