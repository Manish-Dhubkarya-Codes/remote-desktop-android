param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class RdAdminClick {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("shcore.dll")] public static extern int SetProcessDpiAwareness(int awareness);
  [DllImport("user32.dll")] public static extern uint SendInput(uint count, INPUT64[] inputs, int bytes);
  [DllImport("user32.dll", EntryPoint = "SendInput")] public static extern uint SendInput32(uint count, INPUT32[] inputs, int bytes);
  [StructLayout(LayoutKind.Explicit, Size = 40)]
  public struct INPUT64 {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public int dx;
    [FieldOffset(12)] public int dy;
    [FieldOffset(16)] public uint mouseData;
    [FieldOffset(20)] public uint dwFlags;
    [FieldOffset(24)] public uint time;
    [FieldOffset(32)] public ulong extra;
  }
  [StructLayout(LayoutKind.Explicit, Size = 28)]
  public struct INPUT32 {
    [FieldOffset(0)] public uint type;
    [FieldOffset(4)] public int dx;
    [FieldOffset(8)] public int dy;
    [FieldOffset(12)] public uint mouseData;
    [FieldOffset(16)] public uint dwFlags;
    [FieldOffset(20)] public uint time;
    [FieldOffset(24)] public uint extra;
  }
  [DllImport("user32.dll")] public static extern bool SetSystemCursor(IntPtr hcur, uint id);
  [DllImport("user32.dll")] public static extern IntPtr CopyImage(IntPtr h, uint type, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, IntPtr c, uint d);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr inst, int hx, int hy, int w, int h, byte[] andMask, byte[] xorMask);
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("advapi32.dll")] public static extern IntPtr GetSidSubAuthority(IntPtr sid, uint index);
  [DllImport("advapi32.dll")] public static extern IntPtr GetSidSubAuthorityCount(IntPtr sid);
  [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  static POINT parked;
  static bool held;
  static uint[] ids = new uint[] { 32512, 32513, 32514, 32515, 32516, 32640, 32641, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650 };
  static IntPtr blank;
  static bool blanked;
  static IntPtr MakeBlank(int w, int h) {
    if (w < 16 || h < 16 || w > 256 || h > 256) return IntPtr.Zero;
    int row = ((w + 15) / 16) * 2;
    int len = row * h;
    byte[] andMask = new byte[len];
    byte[] xorMask = new byte[len];
    for (int i = 0; i < len; i++) andMask[i] = 255;
    return CreateCursor(IntPtr.Zero, 0, 0, w, h, andMask, xorMask);
  }
  public static void Prepare() {
    SystemParametersInfo(87, 0, IntPtr.Zero, 0);
    blank = MakeBlank(GetSystemMetrics(13), GetSystemMetrics(14));
    if (blank == IntPtr.Zero) blank = MakeBlank(32, 32);
    if (blank == IntPtr.Zero) blank = MakeBlank(48, 48);
    if (blank == IntPtr.Zero) blank = MakeBlank(64, 64);
    blanked = false;
  }
  public static void Blank() {
    if (blanked || blank == IntPtr.Zero) return;
    blanked = true;
    for (int i = 0; i < ids.Length; i++) {
      IntPtr copy = CopyImage(blank, 2, 0, 0, 0);
      if (copy != IntPtr.Zero) SetSystemCursor(copy, ids[i]);
    }
  }
  public static void Unblank() {
    if (!blanked) return;
    blanked = false;
    SystemParametersInfo(87, 0, IntPtr.Zero, 0);
  }
  public static void Reload() {
    blanked = false;
    SystemParametersInfo(87, 0, IntPtr.Zero, 0);
  }
  static bool SpecialName(string name) {
    if (string.IsNullOrEmpty(name)) return false;
    return name.Equals("Taskmgr", StringComparison.OrdinalIgnoreCase)
      || name.Equals("SnippingTool", StringComparison.OrdinalIgnoreCase)
      || name.Equals("ScreenClippingHost", StringComparison.OrdinalIgnoreCase)
      || name.Equals("ScreenSketch", StringComparison.OrdinalIgnoreCase);
  }
  static bool Special(IntPtr hwnd, bool assume) {
    if (hwnd == IntPtr.Zero) return false;
    uint pid; GetWindowThreadProcessId(hwnd, out pid);
    string name = "";
    try { name = System.Diagnostics.Process.GetProcessById((int)pid).ProcessName; } catch {}
    if (SpecialName(name)) return true;
    IntPtr proc = OpenProcess(0x1000, false, pid);
    if (proc == IntPtr.Zero) return assume;
    bool high = false;
    IntPtr tok;
    if (OpenProcessToken(proc, 0x8, out tok)) {
      int size; GetTokenInformation(tok, 25, IntPtr.Zero, 0, out size);
      if (size > 0) {
        IntPtr buf = Marshal.AllocHGlobal(size);
        int ret;
        if (GetTokenInformation(tok, 25, buf, size, out ret)) {
          IntPtr sid = Marshal.ReadIntPtr(buf);
          byte count = Marshal.ReadByte(GetSidSubAuthorityCount(sid));
          int rid = Marshal.ReadInt32(GetSidSubAuthority(sid, (uint)(count - 1)));
          high = rid >= 0x3000;
        }
        Marshal.FreeHGlobal(buf);
      }
      CloseHandle(tok);
    }
    CloseHandle(proc);
    return high;
  }
  public static bool High(int x, int y) {
    if (Special(WindowFromPoint(new POINT { X = x, Y = y }), true)) return true;
    return Special(GetForegroundWindow(), false);
  }
  static bool[] held = new bool[256];
  static bool[] heldExt = new bool[256];
  static int buttons;
  public static void Awake() {
    try { SetProcessDpiAwareness(2); }
    catch { try { SetProcessDPIAware(); } catch { } }
  }
  static bool IsExtended(int vk) {
    return vk == 0x21 || vk == 0x22 || vk == 0x23 || vk == 0x24 || vk == 0x25 || vk == 0x26 || vk == 0x27 || vk == 0x28
      || vk == 0x2C || vk == 0x2D || vk == 0x2E || vk == 0x5B || vk == 0x5C || vk == 0x5D || vk == 0x6F
      || vk == 0xA3 || vk == 0xA5;
  }
  public static void Place(int x, int y) {
    int vx = GetSystemMetrics(76);
    int vy = GetSystemMetrics(77);
    int vw = GetSystemMetrics(78);
    int vh = GetSystemMetrics(79);
    if (vw > 1 && vh > 1) {
      int ax = (int)Math.Round((x - vx) * 65535.0 / (vw - 1));
      int ay = (int)Math.Round((y - vy) * 65535.0 / (vh - 1));
      if (ax < 0) ax = 0;
      if (ay < 0) ay = 0;
      if (ax > 65535) ax = 65535;
      if (ay > 65535) ay = 65535;
      uint flags = 0xC001;
      if (IntPtr.Size == 8) {
        INPUT64[] one = new INPUT64[1];
        one[0].type = 0;
        one[0].dx = ax;
        one[0].dy = ay;
        one[0].dwFlags = flags;
        if (SendInput(1, one, 40) == 1) return;
      } else {
        INPUT32[] one = new INPUT32[1];
        one[0].type = 0;
        one[0].dx = ax;
        one[0].dy = ay;
        one[0].dwFlags = flags;
        if (SendInput32(1, one, 28) == 1) return;
      }
    }
    SetCursorPos(x, y);
  }
  static uint Flag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  public static void Act(string dir, int x, int y, int button) {
    Place(x, y);
    if (dir == "M") return;
    mouse_event(Flag(dir, button), 0, 0, 0, UIntPtr.Zero);
    int bit = button == 2 ? 4 : button == 1 ? 2 : 1;
    if (dir == "D") buttons |= bit;
    else buttons &= ~bit;
  }
  public static void Key(string dir, int vk, bool forceExtended) {
    if (vk < 1 || vk > 255) return;
    uint flags = dir == "U" ? 0x0002u : 0u;
    bool extended = forceExtended || IsExtended(vk);
    if (extended) flags |= 0x0001u;
    byte scan = (byte)MapVirtualKey((uint)vk, 0);
    keybd_event((byte)vk, scan, flags, UIntPtr.Zero);
    held[vk] = dir != "U";
    if (dir != "U") heldExt[vk] = extended;
  }
  public static void Wheel(int x, int y, int dy, int dx) {
    Place(x, y);
    if (dy != 0) mouse_event(0x0800, 0, 0, unchecked((uint)dy), UIntPtr.Zero);
    if (dx != 0) mouse_event(0x1000, 0, 0, unchecked((uint)dx), UIntPtr.Zero);
  }
  public static void ReleaseAll() {
    for (int vk = 1; vk < 256; vk++) {
      if (held[vk]) Key("U", vk, heldExt[vk]);
    }
    if ((buttons & 1) != 0) mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);
    if ((buttons & 2) != 0) mouse_event(0x0040, 0, 0, 0, UIntPtr.Zero);
    if ((buttons & 4) != 0) mouse_event(0x0010, 0, 0, 0, UIntPtr.Zero);
    buttons = 0;
  }
}
"@
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$reader = New-Object System.IO.StreamReader($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine("ready")
try { [RdAdminClick]::Awake() } catch {}
try {
while (($line = $reader.ReadLine()) -ne $null) {
  $p = $line.Trim().Split(" ")
  if ($p.Length -lt 2) { continue }
  $answer = "ok"
  if ($p[1] -eq "P" -and $p.Length -ge 4) {
    if ([RdAdminClick]::High([int]$p[2], [int]$p[3])) { $answer = "H" } else { $answer = "L" }
  } elseif (($p[1] -eq "D" -or $p[1] -eq "U" -or $p[1] -eq "M") -and $p.Length -ge 5) {
    [RdAdminClick]::Act($p[1], [int]$p[2], [int]$p[3], [int]$p[4])
  } elseif ($p[1] -eq "K" -and $p.Length -ge 4) {
    $ext = $p.Length -ge 5 -and $p[4] -eq "E"
    [RdAdminClick]::Key($p[2], [int]$p[3], $ext)
  } elseif ($p[1] -eq "W" -and $p.Length -ge 5) {
    $dx = 0
    if ($p.Length -ge 6) { $dx = [int]$p[5] }
    [RdAdminClick]::Wheel([int]$p[2], [int]$p[3], [int]$p[4], $dx)
  } elseif ($p[1] -eq "R") {
    [RdAdminClick]::ReleaseAll()
  }
  $writer.WriteLine("$($p[0]) $answer")
}
} finally {
  try { [RdAdminClick]::ReleaseAll() } catch {}
  [RdAdminClick]::Unblank()
  [RdAdminClick]::Reload()
}
