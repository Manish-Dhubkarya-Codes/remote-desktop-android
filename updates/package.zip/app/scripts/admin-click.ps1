param([Parameter(Mandatory = $true)][int]$Port)
Add-Type @"
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public class RdWinInput {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT {
    public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit)] public struct INPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public MOUSEINPUT mi;
  }
  [DllImport("user32.dll")] public static extern uint SendInput(uint n, INPUT[] inputs, int cb);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint data, UIntPtr extra);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
  [DllImport("user32.dll", EntryPoint="SendInput")] public static extern uint SendInputKey(uint n, KINPUT[] inputs, int cb);
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT {
    public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo;
  }
  [StructLayout(LayoutKind.Explicit)] public struct KINPUT {
    [FieldOffset(0)] public uint type;
    [FieldOffset(8)] public KEYBDINPUT ki;
  }
  [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
  [DllImport("user32.dll")] public static extern short VkKeyScan(char ch);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i);
  [DllImport("user32.dll", SetLastError=true)] static extern IntPtr CreateWindowEx(int ex, string cls, string title, int style, int x, int y, int w, int h, IntPtr parent, IntPtr menu, IntPtr inst, IntPtr param);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hwnd, int cmd);
  [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] static extern bool SetWindowDisplayAffinity(IntPtr hwnd, uint affinity);
  [DllImport("user32.dll")] static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT dst, ref SIZE size, IntPtr hdcSrc, ref POINT src, uint key, ref BLENDFUNCTION blend, uint flags);
  [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hwnd);
  [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);
  [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hdc);
  [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
  [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
  [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr obj);
  [DllImport("gdi32.dll")] static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO bmi, uint usage, out IntPtr bits, IntPtr section, uint offset);
  [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx; public int cy; }
  [StructLayout(LayoutKind.Sequential)] struct BLENDFUNCTION { public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat; }
  [StructLayout(LayoutKind.Sequential)] struct BITMAPINFOHEADER {
    public int biSize, biWidth, biHeight; public short biPlanes, biBitCount; public int biCompression, biSizeImage, biXPelsPerMeter, biYPelsPerMeter, biClrUsed, biClrImportant;
  }
  [StructLayout(LayoutKind.Sequential)] struct BITMAPINFO { public BITMAPINFOHEADER bmiHeader; }
  [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr value);
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] static extern bool QueryFullProcessImageName(IntPtr process, int flags, System.Text.StringBuilder name, ref int size);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool OpenProcessToken(IntPtr h, uint acc, out IntPtr tok);
  [DllImport("advapi32.dll", SetLastError=true)] public static extern bool GetTokenInformation(IntPtr tok, int cls, IntPtr buf, int len, out int ret);
  [DllImport("kernel32.dll")] public static extern IntPtr GetCurrentProcess();
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  static bool enabled;
  static bool owner;
  static bool left, middle, right;
  static int targetX, targetY, seenX, seenY;
  static int ownerX, ownerY, ctrlX, ctrlY;
  static int homeX, homeY;
  static bool homeSaved;
  static int publishedOX = -1, publishedOY = -1, publishedCX = -1, publishedCY = -1;
  static bool publishedOwner;
  static int sentTick, idleTick;
  static bool ctrlSeen;
  static IntPtr markHwnd;
  static RdWinInput() {
    try {
      if (!SetProcessDpiAwarenessContext((IntPtr)(-4))) SetProcessDPIAware();
    } catch {
      try { SetProcessDPIAware(); } catch { }
    }
  }
  static List<int> held = new List<int>();
  static List<bool> heldExt = new List<bool>();
  static int Elapsed(int start) { return unchecked(Environment.TickCount - start); }
  public static bool SelfHigh() {
    IntPtr tok;
    if (!OpenProcessToken(GetCurrentProcess(), 0x8, out tok)) return false;
    IntPtr buf = Marshal.AllocHGlobal(8);
    int ret;
    bool elevated = false;
    if (GetTokenInformation(tok, 20, buf, 8, out ret)) elevated = Marshal.ReadInt32(buf) != 0;
    Marshal.FreeHGlobal(buf);
    CloseHandle(tok);
    return elevated;
  }
  static int Axis(int value, int origin, int size) {
    if (size <= 1) return 0;
    int n = (int)Math.Round((value - origin) * 65535.0 / (size - 1));
    if (n < 0) return 0;
    if (n > 65535) return 65535;
    return n;
  }
  static uint ButtonFlag(string dir, int button) {
    if (button == 2) return dir == "D" ? 0x0008u : 0x0010u;
    if (button == 1) return dir == "D" ? 0x0020u : 0x0040u;
    return dir == "D" ? 0x0002u : 0x0004u;
  }
  static void MarkButton(int button, bool down) {
    if (button == 2) right = down;
    else if (button == 1) middle = down;
    else left = down;
  }
  public static void Enable() {
    enabled = true;
    owner = false;
    ctrlSeen = false;
    publishedOwner = false;
    publishedOX = -1;
    POINT p;
    if (GetCursorPos(out p)) {
      ownerX = ctrlX = targetX = seenX = p.X;
      ownerY = ctrlY = targetY = seenY = p.Y;
    }
    sentTick = Environment.TickCount;
    idleTick = sentTick;
    ShowMark(false);
  }
  public static void ReleaseHeld() {
    if (left) Place("U", targetX, targetY, 0, 0);
    if (right) Place("U", targetX, targetY, 2, 0);
    if (middle) Place("U", targetX, targetY, 1, 0);
    for (int i = held.Count - 1; i >= 0; i--) Key(false, held[i], heldExt[i]);
    held.Clear();
    heldExt.Clear();
  }
  public static void Disable() {
    enabled = false;
    owner = false;
    ctrlSeen = false;
    ShowMark(false);
    ReleaseHeld();
  }
  static bool ButtonsDown() { return left || middle || right; }
  static void RememberHome() {
    if (homeSaved || ButtonsDown()) return;
    POINT p;
    if (!GetCursorPos(out p)) return;
    homeX = p.X;
    homeY = p.Y;
    homeSaved = true;
    ownerX = p.X;
    ownerY = p.Y;
  }
  static void RestoreHome() {
    if (!homeSaved || ButtonsDown()) return;
    SetCursorPos(homeX, homeY);
    seenX = homeX;
    seenY = homeY;
    ownerX = homeX;
    ownerY = homeY;
    sentTick = Environment.TickCount;
    homeSaved = false;
  }
  static bool snipWas;
  static bool SnippingOpen() {
    try {
      IntPtr hwnd = GetForegroundWindow();
      uint pid;
      GetWindowThreadProcessId(hwnd, out pid);
      if (pid == 0) return false;
      IntPtr proc = OpenProcess(0x1000, false, pid);
      if (proc == IntPtr.Zero) return false;
      System.Text.StringBuilder sb = new System.Text.StringBuilder(300);
      int n = 300;
      QueryFullProcessImageName(proc, 0, sb, ref n);
      CloseHandle(proc);
      string name = sb.ToString().ToLowerInvariant();
      return name.Contains("snipping") || name.Contains("screensketch") || name.Contains("screenclipping");
    } catch { return false; }
  }
  public static bool Move(int x, int y) {
    if (owner) return true;
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    ctrlSeen = true;
    if (owner) return true;
    bool snip = SnippingOpen();
    if (snipWas && !snip) RestoreHome();
    snipWas = snip;
    if (snip) { SetCursorPos(x, y); return true; }
    if (ButtonsDown()) return Place("M", x, y, 0, 0, 0, false);
    return true;
  }
  public static bool Click(string dir, int x, int y, int button) {
    if (owner) return true;
    bool snip = SnippingOpen();
    snipWas = snip;
    if (!snip && dir == "D") RememberHome();
    bool ok = Place(dir, x, y, button, 0, 0, true);
    MarkButton(button, dir == "D");
    if (!snip && dir != "D") RestoreHome();
    return ok;
  }
  public static bool Double(int x, int y, int button) {
    if (owner) return true;
    Click("D", x, y, button);
    Click("U", x, y, button);
    System.Threading.Thread.Sleep(40);
    Click("D", x, y, button);
    Click("U", x, y, button);
    return true;
  }
  public static bool Wheel(int x, int y, int data, bool horizontal) {
    if (owner) return true;
    RememberHome();
    uint flag = horizontal ? 0x1000u : 0x0800u;
    bool ok = Place("M", x, y, 0, flag, data, true);
    RestoreHome();
    return ok;
  }
  static bool Place(string dir, int x, int y, int button, uint extra) {
    return Place(dir, x, y, button, extra, 0, true);
  }
  static bool SendAbsolute(uint flags, int ax, int ay, int wheel) {
    if (IntPtr.Size == 8) {
      INPUT inp = new INPUT();
      inp.type = 0;
      inp.mi.dx = ax;
      inp.mi.dy = ay;
      inp.mi.mouseData = unchecked((uint)wheel);
      inp.mi.dwFlags = flags;
      if (SendInput(1, new INPUT[] { inp }, Marshal.SizeOf(typeof(INPUT))) != 0) return true;
    }
    mouse_event(flags, (uint)ax, (uint)ay, unchecked((uint)wheel), UIntPtr.Zero);
    return true;
  }
  static bool Place(string dir, int x, int y, int button, uint extra, int wheel, bool moveCursor) {
    ctrlX = x;
    ctrlY = y;
    targetX = x;
    targetY = y;
    sentTick = Environment.TickCount;
    int originX = GetSystemMetrics(76);
    int originY = GetSystemMetrics(77);
    int width = GetSystemMetrics(78);
    int height = GetSystemMetrics(79);
    if (width <= 1) width = GetSystemMetrics(0);
    if (height <= 1) height = GetSystemMetrics(1);
    int ax = Axis(x, originX, width);
    int ay = Axis(y, originY, height);
    uint move = 0x0001u | 0x8000u | 0x4000u;
    if (moveCursor) {
      SendAbsolute(move, ax, ay, 0);
      SetCursorPos(x, y);
    }
    if (dir == "D" || dir == "U") SendAbsolute(move | ButtonFlag(dir, button), ax, ay, 0);
    else if (extra != 0) SendAbsolute(move | extra, ax, ay, wheel);
    return true;
  }
  public static void Key(bool down, int vk, bool extended) {
    if (vk == 0x2C) {
      KINPUT snap = new KINPUT();
      snap.type = 1;
      snap.ki.wVk = 0;
      snap.ki.wScan = 0x37;
      snap.ki.dwFlags = (down ? 0u : 2u) | 1u | 8u;
      if (SendInputKey(1, new KINPUT[] { snap }, Marshal.SizeOf(typeof(KINPUT))) == 0)
        keybd_event(0x2C, 0x37, (down ? 0u : 2u) | 1u, UIntPtr.Zero);
      return;
    }
    if (vk <= 0 || vk > 255) return;
    byte scan = (byte)(MapVirtualKey((uint)vk, 0) & 0xFF);
    uint flags = down ? 0u : 2u;
    if (extended || vk == 0x5B || vk == 0x5C || vk == 0x2C) flags |= 1u;
    KINPUT inp = new KINPUT();
    inp.type = 1;
    inp.ki.wVk = (ushort)vk;
    inp.ki.wScan = scan;
    inp.ki.dwFlags = flags;
    if (SendInputKey(1, new KINPUT[] { inp }, Marshal.SizeOf(typeof(KINPUT))) == 0)
      keybd_event((byte)vk, scan, flags, UIntPtr.Zero);
    int index = -1;
    for (int i = 0; i < held.Count; i++) if (held[i] == vk) { index = i; break; }
    if (down && index < 0) { held.Add(vk); heldExt.Add(extended); }
    if (!down && index >= 0) { held.RemoveAt(index); heldExt.RemoveAt(index); }
  }
  public static bool TypeChar(int codePoint) {
    if (codePoint < 0 || codePoint > 0xFFFF) return false;
    short packed = VkKeyScan((char)codePoint);
    if (packed == -1) return false;
    int vk = packed & 0xFF;
    int mods = (packed >> 8) & 0xFF;
    if ((mods & 1) != 0) Key(true, 0x10, false);
    if ((mods & 2) != 0) Key(true, 0x11, false);
    if ((mods & 4) != 0) Key(true, 0x12, false);
    Key(true, vk, false);
    Key(false, vk, false);
    if ((mods & 4) != 0) Key(false, 0x12, false);
    if ((mods & 2) != 0) Key(false, 0x11, false);
    if ((mods & 1) != 0) Key(false, 0x10, false);
    return true;
  }
  static void Plot(IntPtr bits, int width, int x, int y, int color) {
    if (x < 0 || y < 0 || x >= width || y >= 32) return;
    Marshal.WriteInt32(bits, (y * width + x) * 4, color);
  }
  static void PaintMark(bool blocked) {
    if (markHwnd == IntPtr.Zero) return;
    int width = 32;
    int height = 32;
    BITMAPINFO info = new BITMAPINFO();
    info.bmiHeader.biSize = Marshal.SizeOf(typeof(BITMAPINFOHEADER));
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    IntPtr bits;
    IntPtr screen = GetDC(IntPtr.Zero);
    IntPtr mem = CreateCompatibleDC(screen);
    IntPtr dib = CreateDIBSection(screen, ref info, 0, out bits, IntPtr.Zero, 0);
    IntPtr old = SelectObject(mem, dib);
    int blue = unchecked((int)0xFFEB6325);
    int white = unchecked((int)0xFFFFFFFF);
    int ink = blocked ? unchecked((int)0xFF6B7280) : blue;
    string[] arrow = new string[] {
      "1",
      "12",
      "122",
      "1222",
      "12222",
      "122222",
      "1222222",
      "12222222",
      "122222222",
      "1222222222",
      "12222222222",
      "12222222",
      "12221122",
      "1221 122",
      "121  122",
      "11    12",
      "1     1"
    };
    for (int y = 0; y < arrow.Length; y++) {
      string row = arrow[y];
      for (int x = 0; x < row.Length; x++) {
        char cell = row[x];
        if (cell == '1') Plot(bits, width, x, y, white);
        else if (cell == '2') Plot(bits, width, x, y, ink);
      }
    }
    if (blocked) {
      int cx = 22;
      int cy = 20;
      int red = unchecked((int)0xFF4444EF);
      for (int y = -7; y <= 7; y++) {
        for (int x = -7; x <= 7; x++) {
          int d = x * x + y * y;
          if (d > 36) continue;
          int color = d >= 25 ? white : red;
          if (Math.Abs(x - y) <= 1 && d < 25) color = white;
          Plot(bits, width, cx + x, cy + y, color);
        }
      }
    }
    POINT origin = new POINT();
    POINT dst = new POINT();
    SIZE size = new SIZE();
    size.cx = width;
    size.cy = height;
    BLENDFUNCTION blend = new BLENDFUNCTION();
    blend.BlendOp = 0;
    blend.SourceConstantAlpha = 255;
    blend.AlphaFormat = 1;
    UpdateLayeredWindow(markHwnd, screen, ref dst, ref size, mem, ref origin, 0, ref blend, 2);
    SelectObject(mem, old);
    DeleteObject(dib);
    DeleteDC(mem);
    ReleaseDC(IntPtr.Zero, screen);
  }
  static void EnsureMark() {
    if (markHwnd != IntPtr.Zero) return;
    markHwnd = CreateWindowEx(0x80000 | 0x20 | 0x8 | 0x80 | 0x08000000, "Static", "", unchecked((int)0x80000000), 0, 0, 32, 32, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
    if (markHwnd == IntPtr.Zero) return;
    try { SetWindowDisplayAffinity(markHwnd, 0x11); } catch { }
    PaintMark(false);
  }
  static bool markBlocked;
  public static void ShowMark(bool show) {
    if (!show || !ctrlSeen) {
      if (markHwnd != IntPtr.Zero) ShowWindow(markHwnd, 0);
      return;
    }
    EnsureMark();
    if (markBlocked != owner) { markBlocked = owner; PaintMark(owner); }
    SetWindowPos(markHwnd, new IntPtr(-1), ctrlX, ctrlY, 32, 32, 0x0010 | 0x0040);
    ShowWindow(markHwnd, 8);
  }
  public static string CursorLine() {
    if (!enabled) return "";
    POINT p;
    if (!GetCursorPos(out p)) return "";
    int now = Environment.TickCount;
    bool recent = Elapsed(sentTick) < 450;
    double fromPrev = Math.Sqrt((p.X - seenX) * (p.X - seenX) + (p.Y - seenY) * (p.Y - seenY));
    seenX = p.X;
    seenY = p.Y;
    if (!owner) {
      if (!recent && fromPrev > 12) {
        owner = true;
        idleTick = now;
        ownerX = p.X;
        ownerY = p.Y;
      } else {
        ownerX = homeSaved ? homeX : p.X;
        ownerY = homeSaved ? homeY : p.Y;
      }
    } else if (fromPrev > 3) {
      idleTick = now;
      ownerX = p.X;
      ownerY = p.Y;
    } else if (!recent && Elapsed(idleTick) > 900) {
      owner = false;
    }
    ShowMark(ctrlSeen);
    if (owner == publishedOwner && ownerX == publishedOX && ownerY == publishedOY && ctrlX == publishedCX && ctrlY == publishedCY) return "";
    publishedOwner = owner;
    publishedOX = ownerX;
    publishedOY = ownerY;
    publishedCX = ctrlX;
    publishedCY = ctrlY;
    return "cursor " + (owner ? "1" : "0") + " " + ownerX + " " + ownerY + " " + ctrlX + " " + ctrlY;
  }
}
"@
$client = New-Object System.Net.Sockets.TcpClient("127.0.0.1", $Port)
$stream = $client.GetStream()
$writer = New-Object System.IO.StreamWriter($stream)
$reader = New-Object System.IO.StreamReader($stream)
$writer.NewLine = "`n"
$writer.AutoFlush = $true
$writer.WriteLine($(if ([RdWinInput]::SelfHigh()) { "ready high" } else { "ready low" }))
$skipRestore = $false
try {
  while ($true) {
    $cursor = [RdWinInput]::CursorLine()
    if ($cursor) { $writer.WriteLine($cursor) }
    if (-not $stream.DataAvailable) { Start-Sleep -Milliseconds 12; continue }
    $line = $reader.ReadLine()
    if ($null -eq $line) { break }
    $p = $line.Trim().Split(" ")
    if ($p.Length -lt 2) { continue }
    $id = $p[0]
    $cmd = $p[1]
    if ($cmd -eq "HANDOFF") { $skipRestore = $true; $writer.WriteLine("$id ok"); break }
    $ok = $true
    if ($cmd -eq "ENABLE") { [RdWinInput]::Enable() }
    elseif ($cmd -eq "DISABLE") { [RdWinInput]::Disable() }
    elseif ($cmd -eq "MOVE" -and $p.Length -ge 4) { $ok = [RdWinInput]::Move([int]$p[2], [int]$p[3]) }
    elseif (($cmd -eq "DOWN" -or $cmd -eq "UP") -and $p.Length -ge 5) { $ok = [RdWinInput]::Click($(if ($cmd -eq "DOWN") { "D" } else { "U" }), [int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "DBL" -and $p.Length -ge 5) { $ok = [RdWinInput]::Double([int]$p[2], [int]$p[3], [int]$p[4]) }
    elseif ($cmd -eq "WHEEL" -and $p.Length -ge 6) { $ok = [RdWinInput]::Wheel([int]$p[2], [int]$p[3], [int]$p[4], $p[5] -eq "1") }
    elseif ($cmd -eq "KEY" -and $p.Length -ge 5) { [RdWinInput]::Key($p[2] -eq "d", [int]$p[3], $p[4] -eq "1") }
    elseif ($cmd -eq "TEXT" -and $p.Length -ge 3) { $ok = [RdWinInput]::TypeChar([int]$p[2]) }
    $writer.WriteLine("$id $(if ($ok) { 'ok' } else { 'fail' })")
  }
} finally {
  if (-not $skipRestore) { [RdWinInput]::Disable() }
  $writer.Dispose()
  $reader.Dispose()
  $client.Close()
}
