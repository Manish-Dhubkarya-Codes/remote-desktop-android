Add-Type -Namespace RdHide -Name Cur -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr inst, int xHot, int yHot, int w, int h, IntPtr and, IntPtr xor);
[DllImport("user32.dll")] public static extern bool SetSystemCursor(IntPtr cursor, uint id);
[DllImport("user32.dll")] public static extern bool DestroyCursor(IntPtr cursor);
public static void Hide() {
  uint[] ids = new uint[] { 32512, 32513, 32514, 32515, 32516, 32640, 32641, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650 };
  foreach (uint id in ids) {
    byte[] and = new byte[128];
    byte[] xor = new byte[128];
    for (int i = 0; i < 128; i++) and[i] = 255;
    IntPtr a = System.Runtime.InteropServices.Marshal.AllocHGlobal(128);
    IntPtr x = System.Runtime.InteropServices.Marshal.AllocHGlobal(128);
    System.Runtime.InteropServices.Marshal.Copy(and, 0, a, 128);
    System.Runtime.InteropServices.Marshal.Copy(xor, 0, x, 128);
    IntPtr blank = CreateCursor(IntPtr.Zero, 0, 0, 32, 32, a, x);
    System.Runtime.InteropServices.Marshal.FreeHGlobal(a);
    System.Runtime.InteropServices.Marshal.FreeHGlobal(x);
    SetSystemCursor(blank, id);
  }
}
'@
[RdHide.Cur]::Hide()
