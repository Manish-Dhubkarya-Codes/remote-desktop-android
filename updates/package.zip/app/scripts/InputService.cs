using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Threading;

namespace RemoteDesktopInput
{
  public class RdService : ServiceBase
  {
    public RdService()
    {
      ServiceName = "RemoteDesktopInput";
      CanStop = true;
      AutoLog = true;
    }

    protected override void OnStart(string[] args) { Hub.Start(); }
    protected override void OnStop() { Hub.Stop(); }

    public static void Main(string[] args)
    {
      if (args.Length > 0 && args[0] == "--helper")
      {
        Helper.Run(args.Length > 1 ? args[1] : "default");
        return;
      }
      ServiceBase.Run(new RdService());
    }
  }

  static class Hub
  {
    static Link userLink;
    static Link secureLink;
    static readonly object Gate = new object();
    static volatile bool running;

    public static void Start()
    {
      running = true;
      try
      {
        Microsoft.Win32.Registry.SetValue(
          @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
          "SoftwareSASGeneration", 3, Microsoft.Win32.RegistryValueKind.DWord);
      }
      catch { }
      new Thread(AcceptLoop) { IsBackground = true }.Start();
      Launch("default");
      Launch("winlogon");
    }

    public static void Stop()
    {
      running = false;
      lock (Gate)
      {
        Close(userLink);
        Close(secureLink);
        userLink = null;
        secureLink = null;
      }
    }

    static void Close(Link link)
    {
      try { if (link != null && link.Writer != null) link.Writer.Dispose(); } catch { }
    }

    static void AcceptLoop()
    {
      while (running)
      {
        NamedPipeServerStream pipe = null;
        try
        {
          PipeSecurity security = new PipeSecurity();
          security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.AuthenticatedUserSid, null), PipeAccessRights.ReadWrite, AccessControlType.Allow));
          security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), PipeAccessRights.FullControl, AccessControlType.Allow));
          pipe = new NamedPipeServerStream("RemoteDesktopInput", PipeDirection.InOut, 10, PipeTransmissionMode.Byte, PipeOptions.None, 4096, 4096, security);
          pipe.WaitForConnection();
          NamedPipeServerStream accepted = pipe;
          pipe = null;
          new Thread(() => Serve(accepted)) { IsBackground = true }.Start();
        }
        catch
        {
          try { if (pipe != null) pipe.Dispose(); } catch { }
          Thread.Sleep(200);
        }
      }
    }

    static void Serve(NamedPipeServerStream pipe)
    {
      try
      {
        StreamReader reader = new StreamReader(pipe);
        StreamWriter writer = new StreamWriter(pipe);
        writer.NewLine = "\n";
        writer.AutoFlush = true;
        string hello = reader.ReadLine();
        if (hello == null) return;
        if (hello.StartsWith("HELPER "))
        {
          string which = hello.Substring(7).Trim();
          Link link = new Link();
          link.Writer = writer;
          lock (Gate)
          {
            if (which == "winlogon") secureLink = link;
            else userLink = link;
          }
          while (running && pipe.IsConnected)
          {
            string reply = reader.ReadLine();
            if (reply == null) break;
            lock (link.Queue) link.Replies.Enqueue(reply);
            link.Ready.Set();
          }
          lock (Gate)
          {
            if (userLink == link) userLink = null;
            if (secureLink == link) secureLink = null;
          }
          return;
        }
        writer.WriteLine("ok");
        while (running && pipe.IsConnected)
        {
          string line = reader.ReadLine();
          if (line == null) break;
          writer.WriteLine(Handle(line));
        }
      }
      catch { }
      finally { try { pipe.Dispose(); } catch { } }
    }

    static string Handle(string line)
    {
      if (line == "SAS")
      {
        try { Native.SendSAS(false); return "ok"; }
        catch { return "fail"; }
      }
      if (line == "PING") return "ok";
      string desktop = SecureDesktop() ? "winlogon" : "default";
      Link link = LinkFor(desktop);
      if (link == null)
      {
        Launch(desktop);
        for (int i = 0; i < 20 && link == null; i++)
        {
          Thread.Sleep(100);
          link = LinkFor(desktop);
        }
      }
      if (link == null) return "fail";
      lock (link.Queue) link.Replies.Clear();
      link.Ready.Reset();
      try { link.Writer.WriteLine(line); }
      catch { return "fail"; }
      if (!link.Ready.WaitOne(2000)) return "fail";
      lock (link.Queue) return link.Replies.Count > 0 ? link.Replies.Dequeue() : "fail";
    }

    static Link LinkFor(string desktop)
    {
      lock (Gate) return desktop == "winlogon" ? secureLink : userLink;
    }

    static bool SecureDesktop()
    {
      uint session = Native.WTSGetActiveConsoleSessionId();
      if (session == 0xFFFFFFFF) return false;
      if (HasProcess("LogonUI", session) || HasProcess("consent", session)) return true;
      return false;
    }

    static bool HasProcess(string name, uint session)
    {
      try
      {
        Process[] found = Process.GetProcessesByName(name);
        for (int i = 0; i < found.Length; i++)
        {
          try { if ((uint)found[i].SessionId == session) return true; } catch { }
        }
      }
      catch { }
      return false;
    }

    static void Launch(string desktop)
    {
      try
      {
        string exe = Process.GetCurrentProcess().MainModule.FileName;
        uint session = Native.WTSGetActiveConsoleSessionId();
        if (session == 0xFFFFFFFF) return;
        IntPtr token = Native.SystemToken(session);
        if (token == IntPtr.Zero) token = desktop == "winlogon" ? IntPtr.Zero : Native.DesktopToken(session);
        if (token == IntPtr.Zero) return;
        string station = desktop == "winlogon" ? "winsta0\\Winlogon" : "winsta0\\Default";
        Native.STARTUPINFO info = new Native.STARTUPINFO();
        info.cb = Marshal.SizeOf(typeof(Native.STARTUPINFO));
        info.lpDesktop = station;
        Native.PROCESS_INFORMATION process;
        string command = "\"" + exe + "\" --helper " + desktop;
        Native.CreateProcessAsUser(token, null, command, IntPtr.Zero, IntPtr.Zero, false, 0x08000000, IntPtr.Zero, null, ref info, out process);
        Native.CloseHandle(token);
        Native.CloseHandle(process.hThread);
        Native.CloseHandle(process.hProcess);
      }
      catch { }
    }

    class Link
    {
      public StreamWriter Writer;
      public readonly Queue<string> Replies = new Queue<string>();
      public readonly object Queue = new object();
      public readonly ManualResetEvent Ready = new ManualResetEvent(false);
    }
  }

  static class Helper
  {
    static bool secure;
    static int lastX = int.MinValue;
    static int lastY = int.MinValue;
    static int homeX;
    static int homeY;
    static bool homeSaved;
    static bool left, right, middle, back, forward;

    public static void Run(string desktop)
    {
      secure = desktop == "winlogon";
      for (int attempt = 0; attempt < 50; attempt++)
      {
        try
        {
          NamedPipeClientStream pipe = new NamedPipeClientStream(".", "RemoteDesktopInput", PipeDirection.InOut);
          pipe.Connect(1000);
          StreamReader reader = new StreamReader(pipe);
          StreamWriter writer = new StreamWriter(pipe);
          writer.NewLine = "\n";
          writer.AutoFlush = true;
          writer.WriteLine("HELPER " + desktop);
          while (true)
          {
            string line = reader.ReadLine();
            if (line == null) break;
            bool ok = Command(line);
            writer.WriteLine(ok ? "ok" : "fail");
          }
          return;
        }
        catch { Thread.Sleep(200); }
      }
    }

    static bool DownButtons() { return left || right || middle || back || forward; }

    static bool Command(string line)
    {
      string[] parts = line.Split(' ');
      if (parts.Length < 1) return false;
      string cmd = parts[0];
      if (cmd == "MOVE" && parts.Length >= 3) return Move(ToInt(parts[1]), ToInt(parts[2]), false, 0);
      if ((cmd == "DOWN" || cmd == "UP") && parts.Length >= 4) return Click(cmd == "DOWN", ToInt(parts[1]), ToInt(parts[2]), ToInt(parts[3]));
      if (cmd == "DBL" && parts.Length >= 4)
      {
        int x = ToInt(parts[1]);
        int y = ToInt(parts[2]);
        int button = ToInt(parts[3]);
        Click(true, x, y, button);
        Click(false, x, y, button);
        Thread.Sleep(40);
        Click(true, x, y, button);
        Click(false, x, y, button);
        return true;
      }
      if (cmd == "WHEEL" && parts.Length >= 5) return Wheel(ToInt(parts[1]), ToInt(parts[2]), ToInt(parts[3]), parts[4] == "1");
      if (cmd == "KEY" && parts.Length >= 4) { Key(parts[1] == "d", ToInt(parts[2]), parts[3] == "1"); return true; }
      if (cmd == "TEXT" && parts.Length >= 2) return Text(ToInt(parts[1]));
      return false;
    }

    static int ToInt(string value)
    {
      int parsed;
      return int.TryParse(value, out parsed) ? parsed : 0;
    }

    static bool Move(int x, int y, bool force, int buttonFlags)
    {
      int dx = lastX == int.MinValue ? 0 : x - lastX;
      int dy = lastY == int.MinValue ? 0 : y - lastY;
      lastX = x;
      lastY = y;
      if (!secure && !force && !DownButtons()) return true;
      Native.SetCursorPos(x, y);
      int originX = Native.GetSystemMetrics(76);
      int originY = Native.GetSystemMetrics(77);
      int width = Native.GetSystemMetrics(78);
      int height = Native.GetSystemMetrics(79);
      if (width <= 1) width = Native.GetSystemMetrics(0);
      if (height <= 1) height = Native.GetSystemMetrics(1);
      int ax = Axis(x, originX, width);
      int ay = Axis(y, originY, height);
      uint flags = 0x0001u | 0x8000u | 0x4000u | (uint)buttonFlags;
      Native.mouse_event(flags, unchecked((uint)ax), unchecked((uint)ay), XData(buttonFlags), UIntPtr.Zero);
      if (!DownButtons() && homeSaved)
      {
        Native.SetCursorPos(homeX, homeY);
        homeSaved = false;
      }
      return true;
    }

    static uint XData(int flags)
    {
      if ((flags & 0x0080) != 0 || (flags & 0x0100) != 0) return back ? 1u : 2u;
      return 0;
    }

    static bool Click(bool down, int x, int y, int button)
    {
      if (down && !DownButtons()) Remember();
      Hold(button, down);
      int flags = ButtonFlags(down, button);
      bool ok = Move(x, y, true, flags);
      if (!down && !DownButtons() && !Snipping()) Restore();
      return ok;
    }

    static void Hold(int button, bool down)
    {
      if (button == 2) right = down;
      else if (button == 1) middle = down;
      else if (button == 3) back = down;
      else if (button == 4) forward = down;
      else left = down;
    }

    static int ButtonFlags(bool down, int button)
    {
      if (button == 2) return down ? 0x0008 : 0x0010;
      if (button == 1) return down ? 0x0020 : 0x0040;
      if (button == 3 || button == 4) return down ? 0x0080 : 0x0100;
      return down ? 0x0002 : 0x0004;
    }

    static bool Wheel(int x, int y, int delta, bool horizontal)
    {
      if (!homeSaved) Remember();
      Move(x, y, true, 0);
      uint flags = horizontal ? 0x1000u : 0x0800u;
      Native.mouse_event(flags, 0, 0, unchecked((uint)delta), UIntPtr.Zero);
      Restore();
      return true;
    }

    static void Key(bool down, int vk, bool extended)
    {
      if (vk == 0x2C)
      {
        Native.KINPUT snap = new Native.KINPUT();
        snap.type = 1;
        snap.ki.wScan = 0x37;
        snap.ki.dwFlags = (down ? 0u : 2u) | 1u | 8u;
        Native.SendInput(1, new Native.KINPUT[] { snap }, Marshal.SizeOf(typeof(Native.KINPUT)));
        return;
      }
      if (vk <= 0 || vk > 255) return;
      uint scan = Native.MapVirtualKey((uint)vk, 0) & 0xFF;
      uint flags = down ? 0u : 2u;
      if (extended || vk == 0x5B || vk == 0x5C) flags |= 1u;
      Native.KINPUT input = new Native.KINPUT();
      input.type = 1;
      input.ki.wVk = (ushort)vk;
      input.ki.wScan = (ushort)scan;
      input.ki.dwFlags = flags;
      if (Native.SendInput(1, new Native.KINPUT[] { input }, Marshal.SizeOf(typeof(Native.KINPUT))) == 0)
        Native.keybd_event((byte)vk, (byte)scan, flags, UIntPtr.Zero);
    }

    static bool Text(int code)
    {
      if (code < 1 || code > 0xFFFF) return false;
      Native.KINPUT down = new Native.KINPUT();
      down.type = 1;
      down.ki.wScan = (ushort)code;
      down.ki.dwFlags = 4u;
      Native.KINPUT up = new Native.KINPUT();
      up.type = 1;
      up.ki.wScan = (ushort)code;
      up.ki.dwFlags = 4u | 2u;
      Native.SendInput(2, new Native.KINPUT[] { down, up }, Marshal.SizeOf(typeof(Native.KINPUT)));
      return true;
    }

    static bool Clipped()
    {
      Native.RECT clip;
      if (!Native.GetClipCursor(out clip)) return false;
      int width = Native.GetSystemMetrics(78);
      int height = Native.GetSystemMetrics(79);
      if (width < 100 || height < 100) return false;
      return (clip.Right - clip.Left) < width - 8 || (clip.Bottom - clip.Top) < height - 8;
    }

    static int Axis(int value, int origin, int size)
    {
      if (size <= 1) return 0;
      int n = (int)Math.Round((value - origin) * 65535.0 / (size - 1));
      if (n < 0) return 0;
      if (n > 65535) return 65535;
      return n;
    }

    static void Remember()
    {
      Native.POINT point;
      if (!Native.GetCursorPos(out point)) return;
      homeX = point.X;
      homeY = point.Y;
      homeSaved = true;
    }

    static bool Snipping()
    {
      try
      {
        IntPtr hwnd = Native.GetForegroundWindow();
        uint pid;
        Native.GetWindowThreadProcessId(hwnd, out pid);
        if (pid == 0) return false;
        IntPtr proc = Native.OpenProcess(0x1000, false, pid);
        if (proc == IntPtr.Zero) return false;
        System.Text.StringBuilder name = new System.Text.StringBuilder(300);
        int size = 300;
        Native.QueryFullProcessImageName(proc, 0, name, ref size);
        Native.CloseHandle(proc);
        string text = name.ToString().ToLowerInvariant();
        System.Text.StringBuilder title = new System.Text.StringBuilder(200);
        Native.GetWindowText(hwnd, title, 200);
        System.Text.StringBuilder cls = new System.Text.StringBuilder(200);
        Native.GetClassName(hwnd, cls, 200);
        string extra = (title.ToString() + " " + cls.ToString()).ToLowerInvariant();
        return text.Contains("snipping") || text.Contains("screensketch") || text.Contains("screenclip") || text.Contains("pickerhost") || extra.Contains("snip") || extra.Contains("clip");
      }
      catch { return false; }
    }

    static void Restore()
    {
      if (Snipping()) return;
      if (!secure && homeSaved) {
        Native.SetCursorPos(homeX, homeY);
        homeSaved = false;
      }
      if (!Snipping()) ShowSystemCursor();
    }

    static bool cursorHidden;
    static void HideSystemCursor()
    {
      if (cursorHidden) return;
      byte[] andMask = new byte[128];
      byte[] xorMask = new byte[128];
      for (int i = 0; i < andMask.Length; i++) andMask[i] = 0xFF;
      uint[] ids = new uint[] { 32512, 32513, 32514, 32515, 32516, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650, 32651 };
      for (int i = 0; i < ids.Length; i++)
      {
        IntPtr blank = Native.CreateCursor(IntPtr.Zero, 0, 0, 32, 32, andMask, xorMask);
        if (blank != IntPtr.Zero) Native.SetSystemCursor(blank, ids[i]);
      }
      cursorHidden = true;
    }

    static void ShowSystemCursor()
    {
      if (!cursorHidden) return;
      Native.SystemParametersInfo(0x0057, 0, IntPtr.Zero, 0);
      cursorHidden = false;
    }
  }

  static class Native
  {
    [DllImport("sas.dll")] public static extern void SendSAS(bool AsUser);
    [DllImport("kernel32.dll")] public static extern uint WTSGetActiveConsoleSessionId();
    [DllImport("wtsapi32.dll", SetLastError = true)] static extern bool WTSQueryUserToken(uint SessionId, out IntPtr phToken);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool DuplicateTokenEx(IntPtr hExistingToken, uint dwDesiredAccess, IntPtr lpTokenAttributes, int ImpersonationLevel, int TokenType, out IntPtr phNewToken);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr TokenHandle, int TokenInformationClass, IntPtr TokenInformation, int TokenInformationLength, out int ReturnLength);
    [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
    [DllImport("user32.dll", SetLastError = true)] static extern IntPtr OpenWindowStation(string name, bool inherit, uint access);
    [DllImport("user32.dll", SetLastError = true)] static extern IntPtr OpenDesktop(string name, uint flags, bool inherit, uint access);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetSecurityInfo(IntPtr handle, int type, int info, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr descriptor);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool SetSecurityInfo(IntPtr handle, int type, int info, IntPtr owner, IntPtr group, IntPtr dacl, IntPtr sacl);
    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool CreateProcessAsUser(IntPtr hToken, string app, string command, IntPtr processAttributes, IntPtr threadAttributes, bool inherit, uint flags, IntPtr environment, string directory, ref STARTUPINFO startup, out PROCESS_INFORMATION process);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hwnd, System.Text.StringBuilder text, int count);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr hwnd, System.Text.StringBuilder text, int count);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] public static extern bool QueryFullProcessImageName(IntPtr process, int flags, System.Text.StringBuilder name, ref int size);
    [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern bool SetSystemCursor(IntPtr cursor, uint id);
    [DllImport("user32.dll")] public static extern IntPtr CreateCursor(IntPtr inst, int xHot, int yHot, int width, int height, byte[] andMask, byte[] xorMask);
    [DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint action, uint param, IntPtr value, uint winini);
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT point);
    [DllImport("user32.dll")] public static extern bool GetClipCursor(out RECT rect);
    [DllImport("user32.dll")] public static extern int GetSystemMetrics(int index);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
    [DllImport("user32.dll")] public static extern uint MapVirtualKey(uint code, uint map);
    [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);
    [DllImport("user32.dll", EntryPoint = "SendInput")] public static extern uint SendInput(uint count, KINPUT[] inputs, int size);

    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public UIntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Explicit, Size = 40)]
    public struct KINPUT
    {
      [FieldOffset(0)] public uint type;
      [FieldOffset(8)] public KEYBDINPUT ki;
    }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct STARTUPINFO
    {
      public int cb;
      public string lpReserved;
      public string lpDesktop;
      public string lpTitle;
      public int dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
      public short wShowWindow;
      public short cbReserved2;
      public IntPtr lpReserved2;
      public IntPtr hStdInput, hStdOutput, hStdError;
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct PROCESS_INFORMATION { public IntPtr hProcess; public IntPtr hThread; public int dwProcessId; public int dwThreadId; }

    public static IntPtr SystemToken(uint session)
    {
      Process[] found = Process.GetProcessesByName("winlogon");
      for (int i = 0; i < found.Length; i++)
      {
        try
        {
          if ((uint)found[i].SessionId != session) continue;
          IntPtr process = OpenProcess(0x0400, false, (uint)found[i].Id);
          if (process == IntPtr.Zero) continue;
          IntPtr token;
          if (!OpenProcessToken(process, 0x0002 | 0x0008 | 0x0001, out token)) { CloseHandle(process); continue; }
          IntPtr dup;
          bool ok = DuplicateTokenEx(token, 0x02000000, IntPtr.Zero, 2, 1, out dup);
          CloseHandle(token);
          CloseHandle(process);
          if (ok) return dup;
        }
        catch { }
      }
      return IntPtr.Zero;
    }

    public static IntPtr DesktopToken(uint session)
    {
      IntPtr user;
      if (!WTSQueryUserToken(session, out user)) return SystemToken(session);
      IntPtr medium;
      if (!DuplicateTokenEx(user, 0x02000000, IntPtr.Zero, 2, 1, out medium)) { CloseHandle(user); return SystemToken(session); }
      CloseHandle(user);
      int needed;
      GetTokenInformation(medium, 19, IntPtr.Zero, 0, out needed);
      if (needed >= IntPtr.Size)
      {
        IntPtr buffer = Marshal.AllocHGlobal(needed);
        if (GetTokenInformation(medium, 19, buffer, needed, out needed))
        {
          IntPtr linked = Marshal.ReadIntPtr(buffer);
          Marshal.FreeHGlobal(buffer);
          if (linked != IntPtr.Zero)
          {
            IntPtr elevated;
            if (DuplicateTokenEx(linked, 0x02000000, IntPtr.Zero, 2, 1, out elevated))
            {
              CloseHandle(linked);
              CloseHandle(medium);
              return elevated;
            }
            CloseHandle(linked);
          }
        }
        else Marshal.FreeHGlobal(buffer);
      }
      return medium;
    }
  }
}
