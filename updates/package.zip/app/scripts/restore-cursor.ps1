Add-Type -Namespace RdFix -Name Cur -MemberDefinition '[DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, System.IntPtr c, uint d);'
[RdFix.Cur]::SystemParametersInfo(87, 0, [System.IntPtr]::Zero, 0) | Out-Null
Write-Host "Cursor restored."
