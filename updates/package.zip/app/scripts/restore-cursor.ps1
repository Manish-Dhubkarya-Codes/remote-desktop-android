# Older agent builds replaced the Windows cursor with a blank one while a
# controller was connected. Reload the cursor scheme (and clear any leftover
# blank-cursor entries) so the owner's cursor is exactly what Windows had.
Add-Type -Namespace RdFix -Name Cur -MemberDefinition '[DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, System.IntPtr c, uint d);'
$names = @("Arrow","Help","AppStarting","Wait","Crosshair","IBeam","NWPen","SizeAll","SizeNESW","SizeNS","SizeNWSE","SizeWE","UpArrow","Hand","No","Pin","Person")
$key = "HKCU:\Control Panel\Cursors"
$fixed = $false
foreach ($name in $names) {
  $value = [string](Get-ItemProperty -Path $key -Name $name -ErrorAction SilentlyContinue).$name
  if ($value -like "*rd-blank.cur*") {
    Set-ItemProperty -Path $key -Name $name -Value ""
    $fixed = $true
  }
}
if ($fixed) {
  Set-ItemProperty -Path $key -Name "(default)" -Value "Windows Default" -ErrorAction SilentlyContinue
}
[RdFix.Cur]::SystemParametersInfo(87, 0, [System.IntPtr]::Zero, 0) | Out-Null
Write-Host "Cursor restored."
