$exe = Join-Path $env:SystemRoot "System32\SnippingTool.exe"
if (Test-Path $exe) { Start-Process $exe } else { Start-Process "ms-screenclip:" }
