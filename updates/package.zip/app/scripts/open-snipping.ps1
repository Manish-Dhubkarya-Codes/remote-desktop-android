# PrintScreen injected from another app does not open Snipping Tool on Windows 11.
# Open the tool window and the display capture together.
$stub = Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\SnippingTool.exe"
if (Test-Path $stub) {
  Start-Process -FilePath $stub
  Start-Sleep -Milliseconds 350
  Start-Process -FilePath $stub -ArgumentList "/clip"
  return
}
$explorer = Join-Path $env:SystemRoot "explorer.exe"
Start-Process -FilePath $explorer -ArgumentList "shell:AppsFolder\Microsoft.ScreenSketch_8wekyb3d8bbwe!App"
Start-Process -FilePath $explorer -ArgumentList "ms-screenclip:"
