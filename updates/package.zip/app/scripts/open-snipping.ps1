# Same launch the Start menu uses for Snipping Tool. Injected PrintScreen is ignored
# by the Windows 11 shell hook, so the key is also sent separately as a real key.
$explorer = Join-Path $env:SystemRoot "explorer.exe"
$opened = $false
try {
  Start-Process -FilePath $explorer -ArgumentList "shell:AppsFolder\Microsoft.ScreenSketch_8wekyb3d8bbwe!App"
  $opened = $true
} catch {}
if (-not $opened) {
  $stub = Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\SnippingTool.exe"
  if (Test-Path $stub) { Start-Process -FilePath $stub }
  else { Start-Process -FilePath $explorer -ArgumentList "ms-screenclip:" }
}
