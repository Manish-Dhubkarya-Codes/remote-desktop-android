# Opens the same Snipping Tool the Start menu opens. The System32 alias
# fails on some Windows 10 and Windows 11 PCs, so try the installed app first.
$started = $false
try {
  $app = Get-StartApps | Where-Object { $_.Name -match 'Snipping Tool|Screen Sketch' } | Select-Object -First 1
  if ($app -and $app.AppID) {
    Start-Process -FilePath (Join-Path $env:SystemRoot "explorer.exe") -ArgumentList ("shell:AppsFolder\" + $app.AppID)
    $started = $true
  }
} catch {}
if (-not $started) {
  Start-Process -FilePath (Join-Path $env:SystemRoot "explorer.exe") -ArgumentList "ms-screenclip:"
}
