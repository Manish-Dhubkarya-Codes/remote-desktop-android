# Opens the snipping bar on Windows 10 and Windows 11. System32\SnippingTool.exe
# is only an app alias on many PCs and does not start.
Start-Process -FilePath (Join-Path $env:SystemRoot "explorer.exe") -ArgumentList "ms-screenclip:"
