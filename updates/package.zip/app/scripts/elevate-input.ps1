param(
  [Parameter(Mandatory = $true)][string]$Script,
  [Parameter(Mandatory = $true)][string]$Port
)
$start = New-Object System.Diagnostics.ProcessStartInfo
$start.FileName = "powershell.exe"
$start.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$Script`" -Port $Port"
$start.UseShellExecute = $true
$start.Verb = "runas"
try { [System.Diagnostics.Process]::Start($start) | Out-Null } catch { exit 1 }
