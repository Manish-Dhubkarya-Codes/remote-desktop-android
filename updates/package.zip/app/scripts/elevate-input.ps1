param(
  [Parameter(Mandatory = $true)][string]$Script,
  [Parameter(Mandatory = $true)][string]$Port,
  [string]$Installer,
  [string]$ServiceSource,
  [string]$ServiceDir
)
$payload = Join-Path $env:TEMP "rd-elevate-run.ps1"
@'
param($Script, $Port, $Installer, $ServiceSource, $ServiceDir)
if ($Installer -and (Test-Path -LiteralPath $Installer)) {
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Installer -Source $ServiceSource -OutDir $ServiceDir
}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File $Script -Port $Port
'@ | Set-Content -LiteralPath $payload -Encoding ASCII
$start = New-Object System.Diagnostics.ProcessStartInfo
$start.FileName = "powershell.exe"
$start.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$payload`" -Script `"$Script`" -Port $Port -Installer `"$Installer`" -ServiceSource `"$ServiceSource`" -ServiceDir `"$ServiceDir`""
$start.UseShellExecute = $true
$start.Verb = "runas"
try { [System.Diagnostics.Process]::Start($start) | Out-Null } catch { exit 1 }
